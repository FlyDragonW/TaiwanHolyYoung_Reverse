﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class main : MonoBehaviour
{
    public GameObject startBtn, input, lose, joker;
    public GameObject[] btns;
    public Text[] texts;
    public Text title, timerText;
    public int questionIndex = 0;
    public float timer;
    public bool isPlaying;
    private string playerName;

    int finalAnswer = 99;
    string answer = "XXXXX";

    public void ReadName(string s)
    {
        playerName = s;
    }
    // Update is called once per frame
    void Update()
    {
        if (isPlaying)
        {
            timer -= Time.deltaTime;
            timerText.text = ((int)timer).ToString();
            if (timer < 0) LOSE();
        }
    }

    public void StartBtn()
    {
        Time.timeScale = 1;
        input.SetActive(false);
        startBtn.SetActive(false);
        foreach (GameObject btn in btns) btn.SetActive(true);
        timer = 30;
        isPlaying = true;
        title.fontSize = 100;
        UpdateQuestion();
    }
    public void TryAgainBtn()
    {
        Time.timeScale = 1;
        SceneManager.LoadScene(0);
    }
    public void ClickBtn(int i)
    {
        if (questionIndex < 5 && i == char.GetNumericValue(answer[questionIndex]))
        {
            questionIndex++;
            UpdateQuestion();
        }
        else if (i == finalAnswer && questionIndex == 5)
        {
            WIN();
        }
        else
        {
            LOSE();
        }
    }

    public void UpdateQuestion()
    {
        if (questionIndex < 5)
        {
            switch (questionIndex)
            {
                case 0:
                    title.text = "how many cards are there in poker?";
                    texts[0].text = "8";
                    texts[1].text = "52";
                    texts[2].text = "343";
                    texts[3].text = "0";
                    break;
                case 1:
                    title.text = "what letter comes after J?";
                    texts[0].text = "J";
                    texts[1].text = "Q";
                    texts[2].text = "K";
                    texts[3].text = "A";
                    break;
                case 2:
                    title.text = "How many suits are there in poker?";
                    texts[0].text = "4";
                    texts[1].text = "3";
                    texts[2].text = "2";
                    texts[3].text = "1";
                    break;
                case 3:
                    title.text = "what does Q in poker mean?";
                    texts[0].text = "Ace";
                    texts[1].text = "Jack";
                    texts[2].text = "Queen";
                    texts[3].text = "King";
                    break;
                case 4:
                    title.text = "what is my suit?";
                    texts[0].text = "♣";
                    texts[1].text = "♦";
                    texts[2].text = "♥";
                    texts[3].text = "♠";
                    break;
            }
        }
        else
        {
            title.text = "what is your suit?";
            if (playerName.Length >= 4 && char.IsNumber(playerName[2]))
            {
                int num = (int)char.GetNumericValue(playerName[2]);
                if ((int)timer >= 10 && secret(num, (int)timer) == 20 && playerName[3].ToString() + playerName[4].ToString() + playerName[5].ToString() + playerName[6].ToString() + playerName[7].ToString() == "shiya")
                {
                    int[] arr = { 1, 3 };
                    finalAnswer = arr[Random.Range(0, 2)];
                }
            }
        }
    }

    int secret(int x, int y)
    {
        if (y == 8 && x == 5)
        {
            return y + x + 2 + questionIndex + name.Length;
        }
        else if (y == 11 || x == 0)
        {
            return questionIndex + 17;
        }
        else if (y == 0 && x == 11)
        {
            return playerName.Length * questionIndex / 2;
        }
        else if (y <= 0 || x > 10)
        {
            return (int)timer * 21;
        }
        else
        {
            return secret(x + 1, y - 1);
        }
    }
    void WIN()
    {
        Time.timeScale = 0;
        joker.SetActive(true);
        title.text = "LoTuX{Y0u_4re                    }";
    }
    void LOSE()
    {
        Time.timeScale = 0;
        lose.SetActive(true);
    }
}
