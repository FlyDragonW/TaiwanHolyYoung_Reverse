﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void UnityEngine.AndroidJavaRunnable::.ctor(System.Object,System.IntPtr)
extern void AndroidJavaRunnable__ctor_m000E4FEB2DE8031A1CD733610D76E2BF60490334 (void);
// 0x00000002 System.Void UnityEngine.AndroidJavaRunnable::Invoke()
extern void AndroidJavaRunnable_Invoke_m98CFB1479B942F71BF29F53CFDAC1CB9DAFAEBE1 (void);
// 0x00000003 System.Void UnityEngine.AndroidJavaException::.ctor(System.String,System.String)
extern void AndroidJavaException__ctor_mD4B5992BB074504F8E86D79EA98752D3CB154541 (void);
// 0x00000004 System.String UnityEngine.AndroidJavaException::get_StackTrace()
extern void AndroidJavaException_get_StackTrace_m28AC922BCC16051CCBA4C7E5F69698264AA7CC27 (void);
// 0x00000005 System.Void UnityEngine.GlobalJavaObjectRef::.ctor(System.IntPtr)
extern void GlobalJavaObjectRef__ctor_mFE5679D1B51F51CBF11721773C0D767286AC22E8 (void);
// 0x00000006 System.Void UnityEngine.GlobalJavaObjectRef::Finalize()
extern void GlobalJavaObjectRef_Finalize_m2EE89F98A391773F885A4A312FD4BD134E0D46D8 (void);
// 0x00000007 System.IntPtr UnityEngine.GlobalJavaObjectRef::op_Implicit(UnityEngine.GlobalJavaObjectRef)
extern void GlobalJavaObjectRef_op_Implicit_m16AE2CD44F8CDE4667F4DA84D2567582544D4F4E (void);
// 0x00000008 System.Void UnityEngine.GlobalJavaObjectRef::Dispose()
extern void GlobalJavaObjectRef_Dispose_m45E67345587866D5A50D250D1C17425110703520 (void);
// 0x00000009 System.Void UnityEngine.AndroidJavaRunnableProxy::.ctor(UnityEngine.AndroidJavaRunnable)
extern void AndroidJavaRunnableProxy__ctor_mB173256AF7629962B226343C4F6F94FFFF7317C3 (void);
// 0x0000000A System.Void UnityEngine.AndroidJavaProxy::.ctor(System.String)
extern void AndroidJavaProxy__ctor_m2832886A0E1BBF6702653A7C6A4609F11FB712C7 (void);
// 0x0000000B System.Void UnityEngine.AndroidJavaProxy::.ctor(UnityEngine.AndroidJavaClass)
extern void AndroidJavaProxy__ctor_mFA05DF6B31FC284C65D378C02A2A34F277DFE6E5 (void);
// 0x0000000C System.Void UnityEngine.AndroidJavaProxy::Finalize()
extern void AndroidJavaProxy_Finalize_m6E4C294F2117D7A07E82A315081C9239AFA217E8 (void);
// 0x0000000D UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaProxy::Invoke(System.String,System.Object[])
extern void AndroidJavaProxy_Invoke_m9D765F3E7DC37C5CB14C4884F2873B48D2F96BFB (void);
// 0x0000000E UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaProxy::Invoke(System.String,UnityEngine.AndroidJavaObject[])
extern void AndroidJavaProxy_Invoke_mCAE9C5E669AD50DE372494E12224FF1F31A43F1D (void);
// 0x0000000F UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaProxy::GetProxyObject()
extern void AndroidJavaProxy_GetProxyObject_mBFD2FBEF9ED9D4AE23DECF5836E5C73A886E2109 (void);
// 0x00000010 System.IntPtr UnityEngine.AndroidJavaProxy::GetRawProxy()
extern void AndroidJavaProxy_GetRawProxy_m685E066A4D378B596CD88385B954AE90CBF328A9 (void);
// 0x00000011 System.Void UnityEngine.AndroidJavaProxy::.cctor()
extern void AndroidJavaProxy__cctor_mB40E77A0644729A8A761CC80A02E99020DD9790A (void);
// 0x00000012 System.Void UnityEngine.AndroidJavaObject::.ctor(System.String,System.Object[])
extern void AndroidJavaObject__ctor_m5A65B5D325C2CEFAC4097A0D3813F8E158178DD7 (void);
// 0x00000013 System.Void UnityEngine.AndroidJavaObject::Dispose()
extern void AndroidJavaObject_Dispose_m2B1593C20B3CE1C8FF95982F638F50985F9DD9E6 (void);
// 0x00000014 System.IntPtr UnityEngine.AndroidJavaObject::GetRawObject()
extern void AndroidJavaObject_GetRawObject_m536F043B5CE2C21369FF6173C9D2A9A62136BC48 (void);
// 0x00000015 System.IntPtr UnityEngine.AndroidJavaObject::GetRawClass()
extern void AndroidJavaObject_GetRawClass_mE4FB4DC4F856A52E10C6AAD0B65BEBF47B5071F5 (void);
// 0x00000016 ReturnType UnityEngine.AndroidJavaObject::Call(System.String,System.Object[])
// 0x00000017 ReturnType UnityEngine.AndroidJavaObject::CallStatic(System.String,System.Object[])
// 0x00000018 System.Void UnityEngine.AndroidJavaObject::DebugPrint(System.String)
extern void AndroidJavaObject_DebugPrint_m047934BF3D1E6676FDDBDA038E1AF387C5413533 (void);
// 0x00000019 System.Void UnityEngine.AndroidJavaObject::_AndroidJavaObject(System.String,System.Object[])
extern void AndroidJavaObject__AndroidJavaObject_m1284CB7198514B8C06A2BF794ACDC909DC26443F (void);
// 0x0000001A System.Void UnityEngine.AndroidJavaObject::.ctor(System.IntPtr)
extern void AndroidJavaObject__ctor_m0CEE7D570807333CE2C193A82AB3AB8D4F873A6B (void);
// 0x0000001B System.Void UnityEngine.AndroidJavaObject::.ctor()
extern void AndroidJavaObject__ctor_m67B4EEAB015B123D5A3EDCAD914B4795A3B67F04 (void);
// 0x0000001C System.Void UnityEngine.AndroidJavaObject::Finalize()
extern void AndroidJavaObject_Finalize_m87374EE46B27BE3559CACED8A1B62475200AB5AA (void);
// 0x0000001D System.Void UnityEngine.AndroidJavaObject::Dispose(System.Boolean)
extern void AndroidJavaObject_Dispose_m87886676A84FA079C0FE45E6C31D790D764652BE (void);
// 0x0000001E ReturnType UnityEngine.AndroidJavaObject::_Call(System.String,System.Object[])
// 0x0000001F ReturnType UnityEngine.AndroidJavaObject::_CallStatic(System.String,System.Object[])
// 0x00000020 UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::AndroidJavaObjectDeleteLocalRef(System.IntPtr)
extern void AndroidJavaObject_AndroidJavaObjectDeleteLocalRef_mB1EEE323CA333E5DB2871794F1E9094E488682E2 (void);
// 0x00000021 UnityEngine.AndroidJavaClass UnityEngine.AndroidJavaObject::AndroidJavaClassDeleteLocalRef(System.IntPtr)
extern void AndroidJavaObject_AndroidJavaClassDeleteLocalRef_m54CF986C577935C4B4FDC72612CCE0F13079AD08 (void);
// 0x00000022 ReturnType UnityEngine.AndroidJavaObject::FromJavaArrayDeleteLocalRef(System.IntPtr)
// 0x00000023 System.IntPtr UnityEngine.AndroidJavaObject::_GetRawObject()
extern void AndroidJavaObject__GetRawObject_mC5B8B60BEF515F5EE2A113D60991A433DA740C69 (void);
// 0x00000024 System.IntPtr UnityEngine.AndroidJavaObject::_GetRawClass()
extern void AndroidJavaObject__GetRawClass_m470EAEBF8B0BD365FD13F1C6F55119836452FDFA (void);
// 0x00000025 System.Void UnityEngine.AndroidJavaClass::.ctor(System.String)
extern void AndroidJavaClass__ctor_mB5466169E1151B8CC44C8FED234D79984B431389 (void);
// 0x00000026 System.Void UnityEngine.AndroidJavaClass::_AndroidJavaClass(System.String)
extern void AndroidJavaClass__AndroidJavaClass_mF481A9584D78F32C64219FDA49CB84B6F0A017DD (void);
// 0x00000027 System.Void UnityEngine.AndroidJavaClass::.ctor(System.IntPtr)
extern void AndroidJavaClass__ctor_mB206D3CB990755BD56E308F61CD43BB9EA4421D0 (void);
// 0x00000028 System.Boolean UnityEngine.AndroidReflection::IsPrimitive(System.Type)
extern void AndroidReflection_IsPrimitive_m48ED73958206D552B937EEC7560184C6C4228F3D (void);
// 0x00000029 System.Boolean UnityEngine.AndroidReflection::IsAssignableFrom(System.Type,System.Type)
extern void AndroidReflection_IsAssignableFrom_mE4CCA11A87A7E49591786C98FFE239D6EA66F8C5 (void);
// 0x0000002A System.IntPtr UnityEngine.AndroidReflection::GetStaticMethodID(System.String,System.String,System.String)
extern void AndroidReflection_GetStaticMethodID_mA7CC0C6E85BD03EA4BFDA8FAF883A4FF9B721C3E (void);
// 0x0000002B System.IntPtr UnityEngine.AndroidReflection::GetMethodID(System.String,System.String,System.String)
extern void AndroidReflection_GetMethodID_m7773DFE09DED5E42B5E6A607A4318318141104E5 (void);
// 0x0000002C System.IntPtr UnityEngine.AndroidReflection::GetConstructorMember(System.IntPtr,System.String)
extern void AndroidReflection_GetConstructorMember_m79D508363805E1AD5FC551644355A1DCF5A01A8A (void);
// 0x0000002D System.IntPtr UnityEngine.AndroidReflection::GetMethodMember(System.IntPtr,System.String,System.String,System.Boolean)
extern void AndroidReflection_GetMethodMember_m6EAFD27B17549F9EF623F5E6341DCAC9E33528CE (void);
// 0x0000002E System.IntPtr UnityEngine.AndroidReflection::NewProxyInstance(System.IntPtr,System.IntPtr)
extern void AndroidReflection_NewProxyInstance_m06C9BF6A4805DDEED85EC565CDED394E15F2E793 (void);
// 0x0000002F System.Void UnityEngine.AndroidReflection::SetNativeExceptionOnProxy(System.IntPtr,System.Exception,System.Boolean)
extern void AndroidReflection_SetNativeExceptionOnProxy_m3AD392FDF28A10F33D16C0BE27A12D31B2C0883F (void);
// 0x00000030 System.Void UnityEngine.AndroidReflection::.cctor()
extern void AndroidReflection__cctor_m8CAB25F51D629BA5AC9986703DE25F9C93E8A454 (void);
// 0x00000031 System.IntPtr UnityEngine._AndroidJNIHelper::CreateJavaProxy(System.IntPtr,UnityEngine.AndroidJavaProxy)
extern void _AndroidJNIHelper_CreateJavaProxy_m6EB0D9FF190B75B8E49397619D1925F442EEBB8A (void);
// 0x00000032 System.IntPtr UnityEngine._AndroidJNIHelper::CreateJavaRunnable(UnityEngine.AndroidJavaRunnable)
extern void _AndroidJNIHelper_CreateJavaRunnable_m247E2AE8370951BEA9D154FC5AC04BE67F222CF1 (void);
// 0x00000033 System.IntPtr UnityEngine._AndroidJNIHelper::InvokeJavaProxyMethod(UnityEngine.AndroidJavaProxy,System.IntPtr,System.IntPtr)
extern void _AndroidJNIHelper_InvokeJavaProxyMethod_m1DB26565DC2BA3FD2AAA889D1EE72979E78EBD71 (void);
// 0x00000034 UnityEngine.jvalue[] UnityEngine._AndroidJNIHelper::CreateJNIArgArray(System.Object[])
extern void _AndroidJNIHelper_CreateJNIArgArray_m2075C9584C3A31C8DFFA5D1DDBEE8C5FFBB95892 (void);
// 0x00000035 System.Object UnityEngine._AndroidJNIHelper::UnboxArray(UnityEngine.AndroidJavaObject)
extern void _AndroidJNIHelper_UnboxArray_mD9697E8557EB29A0CFFC3A4423366F75B74C4F1D (void);
// 0x00000036 System.Object UnityEngine._AndroidJNIHelper::Unbox(UnityEngine.AndroidJavaObject)
extern void _AndroidJNIHelper_Unbox_mD43DC20EB0E844E2E3E9373EDDB825B5E61FC0BB (void);
// 0x00000037 UnityEngine.AndroidJavaObject UnityEngine._AndroidJNIHelper::Box(System.Object)
extern void _AndroidJNIHelper_Box_mB45F80703BDE58472E812A2122DC70CAFC4E5023 (void);
// 0x00000038 System.Void UnityEngine._AndroidJNIHelper::DeleteJNIArgArray(System.Object[],UnityEngine.jvalue[])
extern void _AndroidJNIHelper_DeleteJNIArgArray_mFA2A3664183847343FBB1F76ACD32DE1B1ED0681 (void);
// 0x00000039 System.IntPtr UnityEngine._AndroidJNIHelper::ConvertToJNIArray(System.Array)
extern void _AndroidJNIHelper_ConvertToJNIArray_mA0E7A187566E19273CEE6D3BAA053B2178FA6850 (void);
// 0x0000003A ArrayType UnityEngine._AndroidJNIHelper::ConvertFromJNIArray(System.IntPtr)
// 0x0000003B System.IntPtr UnityEngine._AndroidJNIHelper::GetConstructorID(System.IntPtr,System.Object[])
extern void _AndroidJNIHelper_GetConstructorID_m7506B43EEFEA5F37F1548F63497D31378460FC61 (void);
// 0x0000003C System.IntPtr UnityEngine._AndroidJNIHelper::GetMethodID(System.IntPtr,System.String,System.Object[],System.Boolean)
// 0x0000003D System.IntPtr UnityEngine._AndroidJNIHelper::GetConstructorID(System.IntPtr,System.String)
extern void _AndroidJNIHelper_GetConstructorID_m80A44C210DFE146BDF2EB8FDB2FF19A6BD0337CE (void);
// 0x0000003E System.IntPtr UnityEngine._AndroidJNIHelper::GetMethodID(System.IntPtr,System.String,System.String,System.Boolean)
extern void _AndroidJNIHelper_GetMethodID_m289D8B1C26B13A8A132565AAFC42FD6C81E99072 (void);
// 0x0000003F System.IntPtr UnityEngine._AndroidJNIHelper::GetMethodIDFallback(System.IntPtr,System.String,System.String,System.Boolean)
extern void _AndroidJNIHelper_GetMethodIDFallback_m48DDC7CB61931DD61B3524E65449AFD4F8B9E9F3 (void);
// 0x00000040 System.String UnityEngine._AndroidJNIHelper::GetSignature(System.Object)
extern void _AndroidJNIHelper_GetSignature_m1F94418EAEB87AF74E495191DC2AA5293136175B (void);
// 0x00000041 System.String UnityEngine._AndroidJNIHelper::GetSignature(System.Object[])
extern void _AndroidJNIHelper_GetSignature_m17AB4F708FC61A101E77C0154684E3E119720FEB (void);
// 0x00000042 System.String UnityEngine._AndroidJNIHelper::GetSignature(System.Object[])
// 0x00000043 System.IntPtr UnityEngine.AndroidJNIHelper::GetConstructorID(System.IntPtr,System.String)
extern void AndroidJNIHelper_GetConstructorID_m2A7EE301E50E6200B15858AD095B9E3DCA061B10 (void);
// 0x00000044 System.IntPtr UnityEngine.AndroidJNIHelper::GetMethodID(System.IntPtr,System.String,System.String,System.Boolean)
extern void AndroidJNIHelper_GetMethodID_m5F33E127418D5DA40590E4AE3814D7ACF7810F6E (void);
// 0x00000045 System.IntPtr UnityEngine.AndroidJNIHelper::CreateJavaRunnable(UnityEngine.AndroidJavaRunnable)
extern void AndroidJNIHelper_CreateJavaRunnable_mAA9F7D043B9EDD0A0665E0CA217A7577962A456F (void);
// 0x00000046 System.IntPtr UnityEngine.AndroidJNIHelper::CreateJavaProxy(UnityEngine.AndroidJavaProxy)
extern void AndroidJNIHelper_CreateJavaProxy_m2694F6C774901F6F33044BC41DA29C7CA3F9C1F5 (void);
// 0x00000047 UnityEngine.jvalue[] UnityEngine.AndroidJNIHelper::CreateJNIArgArray(System.Object[])
extern void AndroidJNIHelper_CreateJNIArgArray_mCA21BB6EB162E1E77E8F95812BD662EA078EDDBF (void);
// 0x00000048 System.Void UnityEngine.AndroidJNIHelper::DeleteJNIArgArray(System.Object[],UnityEngine.jvalue[])
extern void AndroidJNIHelper_DeleteJNIArgArray_m287B584251A89771CD7C767119A350BD6DDACCAB (void);
// 0x00000049 System.IntPtr UnityEngine.AndroidJNIHelper::GetConstructorID(System.IntPtr,System.Object[])
extern void AndroidJNIHelper_GetConstructorID_m06AB8A133FD78AE60E6B5871CBD24609B9444ED7 (void);
// 0x0000004A ArrayType UnityEngine.AndroidJNIHelper::ConvertFromJNIArray(System.IntPtr)
// 0x0000004B System.IntPtr UnityEngine.AndroidJNIHelper::GetMethodID(System.IntPtr,System.String,System.Object[],System.Boolean)
// 0x0000004C System.IntPtr UnityEngine.AndroidJNI::FindClass(System.String)
extern void AndroidJNI_FindClass_mA0D17BF36250F96F40D8DCF193A7C65E6F6DED7F (void);
// 0x0000004D System.IntPtr UnityEngine.AndroidJNI::FromReflectedMethod(System.IntPtr)
extern void AndroidJNI_FromReflectedMethod_m4483E987AEC5B258356E5A89F4C3865573AADFE6 (void);
// 0x0000004E System.IntPtr UnityEngine.AndroidJNI::ExceptionOccurred()
extern void AndroidJNI_ExceptionOccurred_m6C27C01B14483F99373608BF1A56CA53BA46F926 (void);
// 0x0000004F System.Void UnityEngine.AndroidJNI::ExceptionClear()
extern void AndroidJNI_ExceptionClear_m90681289A6CEAF160DB188A3E2177F323D996F82 (void);
// 0x00000050 System.IntPtr UnityEngine.AndroidJNI::NewGlobalRef(System.IntPtr)
extern void AndroidJNI_NewGlobalRef_m5F4875C8F71CF25DCC437D2EDB75320C487DB074 (void);
// 0x00000051 System.Void UnityEngine.AndroidJNI::DeleteGlobalRef(System.IntPtr)
extern void AndroidJNI_DeleteGlobalRef_m0420C00BACE4BD46DD58F8738DFD9EE8189F542A (void);
// 0x00000052 System.IntPtr UnityEngine.AndroidJNI::NewWeakGlobalRef(System.IntPtr)
extern void AndroidJNI_NewWeakGlobalRef_m74933FB5C1E361F566A96B25CF096C770860CD94 (void);
// 0x00000053 System.Void UnityEngine.AndroidJNI::DeleteWeakGlobalRef(System.IntPtr)
extern void AndroidJNI_DeleteWeakGlobalRef_m23C9808936212AC528658CB4989F15580BB0C734 (void);
// 0x00000054 System.IntPtr UnityEngine.AndroidJNI::NewLocalRef(System.IntPtr)
extern void AndroidJNI_NewLocalRef_mA95E1CDBA47E9CEC4D55BBA178F0ACF4219F6E29 (void);
// 0x00000055 System.Void UnityEngine.AndroidJNI::DeleteLocalRef(System.IntPtr)
extern void AndroidJNI_DeleteLocalRef_m2A8137D15FDE9F781B13F71348FD5FFA1F9841BD (void);
// 0x00000056 System.IntPtr UnityEngine.AndroidJNI::NewObject(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_NewObject_mD058F016DBC3D58BF2A64EA84D6943052D01E8B1 (void);
// 0x00000057 System.IntPtr UnityEngine.AndroidJNI::GetObjectClass(System.IntPtr)
extern void AndroidJNI_GetObjectClass_mA8282FA341DF231C0ADD07DE0B0D0E5999EA0207 (void);
// 0x00000058 System.IntPtr UnityEngine.AndroidJNI::GetMethodID(System.IntPtr,System.String,System.String)
extern void AndroidJNI_GetMethodID_mCB601A11C971557E2F89DD968224749BD71D2B3A (void);
// 0x00000059 System.IntPtr UnityEngine.AndroidJNI::GetStaticMethodID(System.IntPtr,System.String,System.String)
extern void AndroidJNI_GetStaticMethodID_m46303AF2AAD855E623DFC9C341E848735B626A77 (void);
// 0x0000005A System.IntPtr UnityEngine.AndroidJNI::NewString(System.String)
extern void AndroidJNI_NewString_mF3FC7534344BDF4B4BD2B2DB5442B06E2402B23F (void);
// 0x0000005B System.IntPtr UnityEngine.AndroidJNI::NewStringFromStr(System.String)
extern void AndroidJNI_NewStringFromStr_mEEF9F3FF518F3CEEE81780A61DDEB0B93D3ED548 (void);
// 0x0000005C System.String UnityEngine.AndroidJNI::GetStringChars(System.IntPtr)
extern void AndroidJNI_GetStringChars_m462C62C322F38797F05A818CEF5C8D235F1F6714 (void);
// 0x0000005D System.String UnityEngine.AndroidJNI::CallStringMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStringMethod_m932940262AEC9A8121916054C90D79866D29C547 (void);
// 0x0000005E System.IntPtr UnityEngine.AndroidJNI::CallObjectMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallObjectMethod_m059D1BE669D486F2A26B40D6B90BF157B84A3CA3 (void);
// 0x0000005F System.Int32 UnityEngine.AndroidJNI::CallIntMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallIntMethod_m5CE09EA0846BF49ABE3E23BC923710A0F1FF4787 (void);
// 0x00000060 System.Boolean UnityEngine.AndroidJNI::CallBooleanMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallBooleanMethod_m6556ACCEDD78DE903521F341072907C4EC90FC96 (void);
// 0x00000061 System.Int16 UnityEngine.AndroidJNI::CallShortMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallShortMethod_m889B967EB2D48E331692B199D2EDABACEC8D5F01 (void);
// 0x00000062 System.SByte UnityEngine.AndroidJNI::CallSByteMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallSByteMethod_m45D5ABB4DDFBFEFC6DB132FC2D8463C501F1E4A5 (void);
// 0x00000063 System.Char UnityEngine.AndroidJNI::CallCharMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallCharMethod_mEF6E65AB2EE0BFAA136878966C42FB21529CB91D (void);
// 0x00000064 System.Single UnityEngine.AndroidJNI::CallFloatMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallFloatMethod_m5BC422FC7D771A08DD18B443CBE3941ACD239FD9 (void);
// 0x00000065 System.Double UnityEngine.AndroidJNI::CallDoubleMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallDoubleMethod_m88A34942D1206EEE8BEA95475722D2E8FFFFC711 (void);
// 0x00000066 System.Int64 UnityEngine.AndroidJNI::CallLongMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallLongMethod_m2AF630255CC50CB6A875E4FC1E13023699504C6E (void);
// 0x00000067 System.String UnityEngine.AndroidJNI::CallStaticStringMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticStringMethod_m728910FCD2307FC8A06ACA204C6308896E1F9634 (void);
// 0x00000068 System.IntPtr UnityEngine.AndroidJNI::CallStaticObjectMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticObjectMethod_mD81C9407381F719A207F5AD038D38A1DDF181306 (void);
// 0x00000069 System.Int32 UnityEngine.AndroidJNI::CallStaticIntMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticIntMethod_mF3BBC45BEA5618BDE9E8C35CF86E4089CB366FAB (void);
// 0x0000006A System.Boolean UnityEngine.AndroidJNI::CallStaticBooleanMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticBooleanMethod_m19B53E56531AEDB6735F1D5651E622E4E823EE92 (void);
// 0x0000006B System.Int16 UnityEngine.AndroidJNI::CallStaticShortMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticShortMethod_m7510F3205665CF3134DD91BAB86458A916B4FA67 (void);
// 0x0000006C System.SByte UnityEngine.AndroidJNI::CallStaticSByteMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticSByteMethod_m91B3565EC4E89DB5DD6994ED9DC03DC1506D9ABD (void);
// 0x0000006D System.Char UnityEngine.AndroidJNI::CallStaticCharMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticCharMethod_mC17CFB28DA453858E2D5189C4A93985A5074ECAC (void);
// 0x0000006E System.Single UnityEngine.AndroidJNI::CallStaticFloatMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticFloatMethod_m50DD95A67820F5A3E3C62556600D985DA697889B (void);
// 0x0000006F System.Double UnityEngine.AndroidJNI::CallStaticDoubleMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticDoubleMethod_m9396E74A4DC7D047134A5DCFFBB343651C1C46FC (void);
// 0x00000070 System.Int64 UnityEngine.AndroidJNI::CallStaticLongMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticLongMethod_m2E00D7592B163630AF5352E89F6180F6B56B8278 (void);
// 0x00000071 System.Void UnityEngine.AndroidJNI::CallStaticVoidMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticVoidMethod_mE1E41BEF150679746147820E058E034CCE9F5FB3 (void);
// 0x00000072 System.IntPtr UnityEngine.AndroidJNI::ToBooleanArray(System.Boolean[])
extern void AndroidJNI_ToBooleanArray_m60F3CE17AE326BA244382C39F0FAE9F86DA1F206 (void);
// 0x00000073 System.IntPtr UnityEngine.AndroidJNI::ToByteArray(System.Byte[])
extern void AndroidJNI_ToByteArray_mA20FD81095A5C55B49F5362F586258D6E1361F14 (void);
// 0x00000074 System.IntPtr UnityEngine.AndroidJNI::ToSByteArray(System.SByte[])
extern void AndroidJNI_ToSByteArray_m5E75BAD1F59BF0993F573E548837DB5BEFD136D0 (void);
// 0x00000075 System.IntPtr UnityEngine.AndroidJNI::ToCharArray(System.Char[])
extern void AndroidJNI_ToCharArray_mA2081BFCF1F054F7AF1FF6C02DBCD3DDF842ACD1 (void);
// 0x00000076 System.IntPtr UnityEngine.AndroidJNI::ToShortArray(System.Int16[])
extern void AndroidJNI_ToShortArray_m5C720FF3C3E8A33E7F0679DEE1CF29279A3F6EE4 (void);
// 0x00000077 System.IntPtr UnityEngine.AndroidJNI::ToIntArray(System.Int32[])
extern void AndroidJNI_ToIntArray_m4F7B434E1B855ED0CCA21E5D3FE94BABCC246805 (void);
// 0x00000078 System.IntPtr UnityEngine.AndroidJNI::ToLongArray(System.Int64[])
extern void AndroidJNI_ToLongArray_mBE89CB90348200EFD4A8939241A030FF7FB3B205 (void);
// 0x00000079 System.IntPtr UnityEngine.AndroidJNI::ToFloatArray(System.Single[])
extern void AndroidJNI_ToFloatArray_m805231BFD408148D10ECB4B19935D49FD2E59E73 (void);
// 0x0000007A System.IntPtr UnityEngine.AndroidJNI::ToDoubleArray(System.Double[])
extern void AndroidJNI_ToDoubleArray_m5365EB845635C82BAFC86696C6083F22A79F49EE (void);
// 0x0000007B System.IntPtr UnityEngine.AndroidJNI::ToObjectArray(System.IntPtr[],System.IntPtr)
extern void AndroidJNI_ToObjectArray_mED4ECAFBCB6517A46658F92FCCF2492ADE08C3B5 (void);
// 0x0000007C System.Boolean[] UnityEngine.AndroidJNI::FromBooleanArray(System.IntPtr)
extern void AndroidJNI_FromBooleanArray_m5EE3946B096CBAFCDED6E33AD0BEDF392CE3C2E3 (void);
// 0x0000007D System.Byte[] UnityEngine.AndroidJNI::FromByteArray(System.IntPtr)
extern void AndroidJNI_FromByteArray_m2E5209DB888EB1CFD47E732AB5F565CEB351B766 (void);
// 0x0000007E System.SByte[] UnityEngine.AndroidJNI::FromSByteArray(System.IntPtr)
extern void AndroidJNI_FromSByteArray_m46D4FF95707BEC89FB35BADAC0D778D1F9FFE600 (void);
// 0x0000007F System.Char[] UnityEngine.AndroidJNI::FromCharArray(System.IntPtr)
extern void AndroidJNI_FromCharArray_mC965E533F95CD2ED4BE5DB99579D6C9723F9FFEF (void);
// 0x00000080 System.Int16[] UnityEngine.AndroidJNI::FromShortArray(System.IntPtr)
extern void AndroidJNI_FromShortArray_m155B1A19DC1AA710079277D8392ECC84578C095C (void);
// 0x00000081 System.Int32[] UnityEngine.AndroidJNI::FromIntArray(System.IntPtr)
extern void AndroidJNI_FromIntArray_m0139900B65713B2EC09EB03596157D39968E81BC (void);
// 0x00000082 System.Int64[] UnityEngine.AndroidJNI::FromLongArray(System.IntPtr)
extern void AndroidJNI_FromLongArray_mCFB950966DB71AE966C3CE5B8B2FC63BD874B3EC (void);
// 0x00000083 System.Single[] UnityEngine.AndroidJNI::FromFloatArray(System.IntPtr)
extern void AndroidJNI_FromFloatArray_mDC9E8A87B643677DB1CD67FB90EE6AC30A2352C5 (void);
// 0x00000084 System.Double[] UnityEngine.AndroidJNI::FromDoubleArray(System.IntPtr)
extern void AndroidJNI_FromDoubleArray_m069C4F1F762610BA916F674B3125A68634F27AB8 (void);
// 0x00000085 System.Int32 UnityEngine.AndroidJNI::GetArrayLength(System.IntPtr)
extern void AndroidJNI_GetArrayLength_m67AF3E58A9CFD97E7934D2E63D0306865A78DA12 (void);
// 0x00000086 System.IntPtr UnityEngine.AndroidJNI::NewObjectArray(System.Int32,System.IntPtr,System.IntPtr)
extern void AndroidJNI_NewObjectArray_m8B0C45BD47F6563EA916E35BE26691DFA6482A51 (void);
// 0x00000087 System.IntPtr UnityEngine.AndroidJNI::GetObjectArrayElement(System.IntPtr,System.Int32)
extern void AndroidJNI_GetObjectArrayElement_mDD7F2DC202FA14B8E5889755FB02B401C1127AD0 (void);
// 0x00000088 System.Void UnityEngine.AndroidJNI::SetObjectArrayElement(System.IntPtr,System.Int32,System.IntPtr)
extern void AndroidJNI_SetObjectArrayElement_m5D80CF792A1C492F97EC3378E36FFF458BAFD8D1 (void);
// 0x00000089 System.Void UnityEngine.AndroidJNISafe::CheckException()
extern void AndroidJNISafe_CheckException_mD1BB59188CDDCC2559F595CE1240E6BB12F1D546 (void);
// 0x0000008A System.Void UnityEngine.AndroidJNISafe::DeleteGlobalRef(System.IntPtr)
extern void AndroidJNISafe_DeleteGlobalRef_mC71D9B4DBED2AB66D49764253BA8DE912F731A40 (void);
// 0x0000008B System.Void UnityEngine.AndroidJNISafe::DeleteWeakGlobalRef(System.IntPtr)
extern void AndroidJNISafe_DeleteWeakGlobalRef_m9B39A30D764938DC4C8D526321520701D77D34A7 (void);
// 0x0000008C System.Void UnityEngine.AndroidJNISafe::DeleteLocalRef(System.IntPtr)
extern void AndroidJNISafe_DeleteLocalRef_m80503AA6C85CE46E8CE72C62215E1BE62964424D (void);
// 0x0000008D System.IntPtr UnityEngine.AndroidJNISafe::NewString(System.String)
extern void AndroidJNISafe_NewString_m6D6411F7DACFD383054457D88C0F0F1F8AE0CFB9 (void);
// 0x0000008E System.String UnityEngine.AndroidJNISafe::GetStringChars(System.IntPtr)
extern void AndroidJNISafe_GetStringChars_m21A07825755C0A9AF91F8248A1C98F861E26928F (void);
// 0x0000008F System.IntPtr UnityEngine.AndroidJNISafe::GetObjectClass(System.IntPtr)
extern void AndroidJNISafe_GetObjectClass_m78626C2B107D46FA9276B6FD32D746EEB81E8D2D (void);
// 0x00000090 System.IntPtr UnityEngine.AndroidJNISafe::GetStaticMethodID(System.IntPtr,System.String,System.String)
extern void AndroidJNISafe_GetStaticMethodID_mDD304107A2DCF7C4FFFC6E820361618693FCD8C7 (void);
// 0x00000091 System.IntPtr UnityEngine.AndroidJNISafe::GetMethodID(System.IntPtr,System.String,System.String)
extern void AndroidJNISafe_GetMethodID_m4E480BAEFB37F467848EC9074C6917A2D8E853DC (void);
// 0x00000092 System.IntPtr UnityEngine.AndroidJNISafe::FromReflectedMethod(System.IntPtr)
extern void AndroidJNISafe_FromReflectedMethod_mA0F291FDD88E4B0BD2242D9846833C696CF64F86 (void);
// 0x00000093 System.IntPtr UnityEngine.AndroidJNISafe::FindClass(System.String)
extern void AndroidJNISafe_FindClass_m921B6BE5C8F1F1A4207761AD07A57C0D5F599DDE (void);
// 0x00000094 System.IntPtr UnityEngine.AndroidJNISafe::NewObject(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_NewObject_mCA783442B4DE3E0071D2C71DE69A655EF8538E2C (void);
// 0x00000095 System.Void UnityEngine.AndroidJNISafe::CallStaticVoidMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticVoidMethod_m965D8C47FDF1388EA6192108063B129C870B382F (void);
// 0x00000096 System.IntPtr UnityEngine.AndroidJNISafe::CallStaticObjectMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticObjectMethod_mFF379E5F210AF38781F1FB59667AC39C4CFA5966 (void);
// 0x00000097 System.String UnityEngine.AndroidJNISafe::CallStaticStringMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticStringMethod_mC5449583711986CFF9CCDAD3F8058D9842229B88 (void);
// 0x00000098 System.Char UnityEngine.AndroidJNISafe::CallStaticCharMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticCharMethod_m435C3A57BC14CCA2F459E1CE9D3E9F084353634C (void);
// 0x00000099 System.Double UnityEngine.AndroidJNISafe::CallStaticDoubleMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticDoubleMethod_mDCA07255A15D31B20FFD77A795A7FD47C8661D1D (void);
// 0x0000009A System.Single UnityEngine.AndroidJNISafe::CallStaticFloatMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticFloatMethod_mCEF7855DF0530B27B6E0B4B1C1E78667FD80B2B6 (void);
// 0x0000009B System.Int64 UnityEngine.AndroidJNISafe::CallStaticLongMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticLongMethod_mA98EE656033866FC4DE05F3F815F76594FA18D84 (void);
// 0x0000009C System.Int16 UnityEngine.AndroidJNISafe::CallStaticShortMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticShortMethod_m134B1C6791FD9A09180ADF481475880F4F8B79A4 (void);
// 0x0000009D System.SByte UnityEngine.AndroidJNISafe::CallStaticSByteMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticSByteMethod_mC9057F28DC0C675701810414D19C7168A68F026D (void);
// 0x0000009E System.Boolean UnityEngine.AndroidJNISafe::CallStaticBooleanMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticBooleanMethod_mF980739844CAA33E0E0ADA82F5177F91E39CCB75 (void);
// 0x0000009F System.Int32 UnityEngine.AndroidJNISafe::CallStaticIntMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticIntMethod_mE174E036EAB1034BA4DC107F534F0F7B6DA8FBC6 (void);
// 0x000000A0 System.IntPtr UnityEngine.AndroidJNISafe::CallObjectMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallObjectMethod_m220EBB62A14A40DD5693A48E5787DE4636D051EA (void);
// 0x000000A1 System.String UnityEngine.AndroidJNISafe::CallStringMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStringMethod_mABFAE9A418A989676CB15D01E5971E431BFD4579 (void);
// 0x000000A2 System.Char UnityEngine.AndroidJNISafe::CallCharMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallCharMethod_m4A39264614C8E7A9E2645F7C0E208062990A9D90 (void);
// 0x000000A3 System.Double UnityEngine.AndroidJNISafe::CallDoubleMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallDoubleMethod_m53CDFD6982DECEB5F155858B4D0B8D7A06B426DD (void);
// 0x000000A4 System.Single UnityEngine.AndroidJNISafe::CallFloatMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallFloatMethod_m95871A924AA515B19EEFD76FC5DABE3E2FAE4909 (void);
// 0x000000A5 System.Int64 UnityEngine.AndroidJNISafe::CallLongMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallLongMethod_m6F9F122D99AB7C95774CE395A98153B705D07931 (void);
// 0x000000A6 System.Int16 UnityEngine.AndroidJNISafe::CallShortMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallShortMethod_mDA06E47602A9F365C91DB7D3B78A699D8A48F861 (void);
// 0x000000A7 System.SByte UnityEngine.AndroidJNISafe::CallSByteMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallSByteMethod_mA5011FBB030ABC0A47C34052A49A7BEBC1F9EDC0 (void);
// 0x000000A8 System.Boolean UnityEngine.AndroidJNISafe::CallBooleanMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallBooleanMethod_m9B26AA2F5828D29D1F1BC3315BABE97F3614EE08 (void);
// 0x000000A9 System.Int32 UnityEngine.AndroidJNISafe::CallIntMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallIntMethod_m1C01B0148542E93B661401AB695295F4DFB334A8 (void);
// 0x000000AA System.Char[] UnityEngine.AndroidJNISafe::FromCharArray(System.IntPtr)
extern void AndroidJNISafe_FromCharArray_mC1C728B67330FD610542B4C2D6B9759F78B2BD17 (void);
// 0x000000AB System.Double[] UnityEngine.AndroidJNISafe::FromDoubleArray(System.IntPtr)
extern void AndroidJNISafe_FromDoubleArray_mB752FB522CD25191E5C6AF8CEFA4553593F784A7 (void);
// 0x000000AC System.Single[] UnityEngine.AndroidJNISafe::FromFloatArray(System.IntPtr)
extern void AndroidJNISafe_FromFloatArray_m97B7BC8546EC3F9CF0784D434D4AA41FBB409892 (void);
// 0x000000AD System.Int64[] UnityEngine.AndroidJNISafe::FromLongArray(System.IntPtr)
extern void AndroidJNISafe_FromLongArray_m687FC548BFA4DC440379619E5C7CB56354E30D59 (void);
// 0x000000AE System.Int16[] UnityEngine.AndroidJNISafe::FromShortArray(System.IntPtr)
extern void AndroidJNISafe_FromShortArray_m227116D8E01EE3568936FB93C97CAEE9062A0A35 (void);
// 0x000000AF System.Byte[] UnityEngine.AndroidJNISafe::FromByteArray(System.IntPtr)
extern void AndroidJNISafe_FromByteArray_mAED5B8EEF34E268BB146A277842089C7FD8A06BB (void);
// 0x000000B0 System.SByte[] UnityEngine.AndroidJNISafe::FromSByteArray(System.IntPtr)
extern void AndroidJNISafe_FromSByteArray_m5825C71BA6941CDF25627AD77CDBE648CB322476 (void);
// 0x000000B1 System.Boolean[] UnityEngine.AndroidJNISafe::FromBooleanArray(System.IntPtr)
extern void AndroidJNISafe_FromBooleanArray_m3F57F10FDDBA3DC358BEF7296F58D819C9EC3BDE (void);
// 0x000000B2 System.Int32[] UnityEngine.AndroidJNISafe::FromIntArray(System.IntPtr)
extern void AndroidJNISafe_FromIntArray_m899EDC375E4983DCF33B5B72E2131DC06AA4B5F0 (void);
// 0x000000B3 System.IntPtr UnityEngine.AndroidJNISafe::ToObjectArray(System.IntPtr[],System.IntPtr)
extern void AndroidJNISafe_ToObjectArray_m0F776C4B1BA875104CCB8345797A9269A3EBCF07 (void);
// 0x000000B4 System.IntPtr UnityEngine.AndroidJNISafe::ToCharArray(System.Char[])
extern void AndroidJNISafe_ToCharArray_m8C8F076F9A471146F6BCF063F7415E89BC0FC801 (void);
// 0x000000B5 System.IntPtr UnityEngine.AndroidJNISafe::ToDoubleArray(System.Double[])
extern void AndroidJNISafe_ToDoubleArray_mCAF30FC9FA2947EBC680D89374A5296D775132A9 (void);
// 0x000000B6 System.IntPtr UnityEngine.AndroidJNISafe::ToFloatArray(System.Single[])
extern void AndroidJNISafe_ToFloatArray_m15157B7C76CE04863F365E7052671AC87D8556E0 (void);
// 0x000000B7 System.IntPtr UnityEngine.AndroidJNISafe::ToLongArray(System.Int64[])
extern void AndroidJNISafe_ToLongArray_m00D8D5A5D1B46639307AA78C5E4E7421EA0FF16A (void);
// 0x000000B8 System.IntPtr UnityEngine.AndroidJNISafe::ToShortArray(System.Int16[])
extern void AndroidJNISafe_ToShortArray_m3591547B05CEABD583A023C267091A536E3F925C (void);
// 0x000000B9 System.IntPtr UnityEngine.AndroidJNISafe::ToByteArray(System.Byte[])
extern void AndroidJNISafe_ToByteArray_m13141E44A84BDC2716432D09131984A4ADFC101F (void);
// 0x000000BA System.IntPtr UnityEngine.AndroidJNISafe::ToSByteArray(System.SByte[])
extern void AndroidJNISafe_ToSByteArray_mEFB80D7817A15C285872B8F3C1A9A1EDEA9ECC34 (void);
// 0x000000BB System.IntPtr UnityEngine.AndroidJNISafe::ToBooleanArray(System.Boolean[])
extern void AndroidJNISafe_ToBooleanArray_m2E622CCA3AB1B19FE519F975391636CA7DECDAF7 (void);
// 0x000000BC System.IntPtr UnityEngine.AndroidJNISafe::ToIntArray(System.Int32[])
extern void AndroidJNISafe_ToIntArray_mA46A79AFCB3909BB90FFF2D20EFDA042E6A4DE97 (void);
// 0x000000BD System.IntPtr UnityEngine.AndroidJNISafe::GetObjectArrayElement(System.IntPtr,System.Int32)
extern void AndroidJNISafe_GetObjectArrayElement_m515AF7717FD44C40A5FFFD6E50DFCD65A35B8FF5 (void);
// 0x000000BE System.Int32 UnityEngine.AndroidJNISafe::GetArrayLength(System.IntPtr)
extern void AndroidJNISafe_GetArrayLength_mB5F7260E652BE95FE9237A47C1E1597306B462C3 (void);
static Il2CppMethodPointer s_methodPointers[190] = 
{
	AndroidJavaRunnable__ctor_m000E4FEB2DE8031A1CD733610D76E2BF60490334,
	AndroidJavaRunnable_Invoke_m98CFB1479B942F71BF29F53CFDAC1CB9DAFAEBE1,
	AndroidJavaException__ctor_mD4B5992BB074504F8E86D79EA98752D3CB154541,
	AndroidJavaException_get_StackTrace_m28AC922BCC16051CCBA4C7E5F69698264AA7CC27,
	GlobalJavaObjectRef__ctor_mFE5679D1B51F51CBF11721773C0D767286AC22E8,
	GlobalJavaObjectRef_Finalize_m2EE89F98A391773F885A4A312FD4BD134E0D46D8,
	GlobalJavaObjectRef_op_Implicit_m16AE2CD44F8CDE4667F4DA84D2567582544D4F4E,
	GlobalJavaObjectRef_Dispose_m45E67345587866D5A50D250D1C17425110703520,
	AndroidJavaRunnableProxy__ctor_mB173256AF7629962B226343C4F6F94FFFF7317C3,
	AndroidJavaProxy__ctor_m2832886A0E1BBF6702653A7C6A4609F11FB712C7,
	AndroidJavaProxy__ctor_mFA05DF6B31FC284C65D378C02A2A34F277DFE6E5,
	AndroidJavaProxy_Finalize_m6E4C294F2117D7A07E82A315081C9239AFA217E8,
	AndroidJavaProxy_Invoke_m9D765F3E7DC37C5CB14C4884F2873B48D2F96BFB,
	AndroidJavaProxy_Invoke_mCAE9C5E669AD50DE372494E12224FF1F31A43F1D,
	AndroidJavaProxy_GetProxyObject_mBFD2FBEF9ED9D4AE23DECF5836E5C73A886E2109,
	AndroidJavaProxy_GetRawProxy_m685E066A4D378B596CD88385B954AE90CBF328A9,
	AndroidJavaProxy__cctor_mB40E77A0644729A8A761CC80A02E99020DD9790A,
	AndroidJavaObject__ctor_m5A65B5D325C2CEFAC4097A0D3813F8E158178DD7,
	AndroidJavaObject_Dispose_m2B1593C20B3CE1C8FF95982F638F50985F9DD9E6,
	AndroidJavaObject_GetRawObject_m536F043B5CE2C21369FF6173C9D2A9A62136BC48,
	AndroidJavaObject_GetRawClass_mE4FB4DC4F856A52E10C6AAD0B65BEBF47B5071F5,
	NULL,
	NULL,
	AndroidJavaObject_DebugPrint_m047934BF3D1E6676FDDBDA038E1AF387C5413533,
	AndroidJavaObject__AndroidJavaObject_m1284CB7198514B8C06A2BF794ACDC909DC26443F,
	AndroidJavaObject__ctor_m0CEE7D570807333CE2C193A82AB3AB8D4F873A6B,
	AndroidJavaObject__ctor_m67B4EEAB015B123D5A3EDCAD914B4795A3B67F04,
	AndroidJavaObject_Finalize_m87374EE46B27BE3559CACED8A1B62475200AB5AA,
	AndroidJavaObject_Dispose_m87886676A84FA079C0FE45E6C31D790D764652BE,
	NULL,
	NULL,
	AndroidJavaObject_AndroidJavaObjectDeleteLocalRef_mB1EEE323CA333E5DB2871794F1E9094E488682E2,
	AndroidJavaObject_AndroidJavaClassDeleteLocalRef_m54CF986C577935C4B4FDC72612CCE0F13079AD08,
	NULL,
	AndroidJavaObject__GetRawObject_mC5B8B60BEF515F5EE2A113D60991A433DA740C69,
	AndroidJavaObject__GetRawClass_m470EAEBF8B0BD365FD13F1C6F55119836452FDFA,
	AndroidJavaClass__ctor_mB5466169E1151B8CC44C8FED234D79984B431389,
	AndroidJavaClass__AndroidJavaClass_mF481A9584D78F32C64219FDA49CB84B6F0A017DD,
	AndroidJavaClass__ctor_mB206D3CB990755BD56E308F61CD43BB9EA4421D0,
	AndroidReflection_IsPrimitive_m48ED73958206D552B937EEC7560184C6C4228F3D,
	AndroidReflection_IsAssignableFrom_mE4CCA11A87A7E49591786C98FFE239D6EA66F8C5,
	AndroidReflection_GetStaticMethodID_mA7CC0C6E85BD03EA4BFDA8FAF883A4FF9B721C3E,
	AndroidReflection_GetMethodID_m7773DFE09DED5E42B5E6A607A4318318141104E5,
	AndroidReflection_GetConstructorMember_m79D508363805E1AD5FC551644355A1DCF5A01A8A,
	AndroidReflection_GetMethodMember_m6EAFD27B17549F9EF623F5E6341DCAC9E33528CE,
	AndroidReflection_NewProxyInstance_m06C9BF6A4805DDEED85EC565CDED394E15F2E793,
	AndroidReflection_SetNativeExceptionOnProxy_m3AD392FDF28A10F33D16C0BE27A12D31B2C0883F,
	AndroidReflection__cctor_m8CAB25F51D629BA5AC9986703DE25F9C93E8A454,
	_AndroidJNIHelper_CreateJavaProxy_m6EB0D9FF190B75B8E49397619D1925F442EEBB8A,
	_AndroidJNIHelper_CreateJavaRunnable_m247E2AE8370951BEA9D154FC5AC04BE67F222CF1,
	_AndroidJNIHelper_InvokeJavaProxyMethod_m1DB26565DC2BA3FD2AAA889D1EE72979E78EBD71,
	_AndroidJNIHelper_CreateJNIArgArray_m2075C9584C3A31C8DFFA5D1DDBEE8C5FFBB95892,
	_AndroidJNIHelper_UnboxArray_mD9697E8557EB29A0CFFC3A4423366F75B74C4F1D,
	_AndroidJNIHelper_Unbox_mD43DC20EB0E844E2E3E9373EDDB825B5E61FC0BB,
	_AndroidJNIHelper_Box_mB45F80703BDE58472E812A2122DC70CAFC4E5023,
	_AndroidJNIHelper_DeleteJNIArgArray_mFA2A3664183847343FBB1F76ACD32DE1B1ED0681,
	_AndroidJNIHelper_ConvertToJNIArray_mA0E7A187566E19273CEE6D3BAA053B2178FA6850,
	NULL,
	_AndroidJNIHelper_GetConstructorID_m7506B43EEFEA5F37F1548F63497D31378460FC61,
	NULL,
	_AndroidJNIHelper_GetConstructorID_m80A44C210DFE146BDF2EB8FDB2FF19A6BD0337CE,
	_AndroidJNIHelper_GetMethodID_m289D8B1C26B13A8A132565AAFC42FD6C81E99072,
	_AndroidJNIHelper_GetMethodIDFallback_m48DDC7CB61931DD61B3524E65449AFD4F8B9E9F3,
	_AndroidJNIHelper_GetSignature_m1F94418EAEB87AF74E495191DC2AA5293136175B,
	_AndroidJNIHelper_GetSignature_m17AB4F708FC61A101E77C0154684E3E119720FEB,
	NULL,
	AndroidJNIHelper_GetConstructorID_m2A7EE301E50E6200B15858AD095B9E3DCA061B10,
	AndroidJNIHelper_GetMethodID_m5F33E127418D5DA40590E4AE3814D7ACF7810F6E,
	AndroidJNIHelper_CreateJavaRunnable_mAA9F7D043B9EDD0A0665E0CA217A7577962A456F,
	AndroidJNIHelper_CreateJavaProxy_m2694F6C774901F6F33044BC41DA29C7CA3F9C1F5,
	AndroidJNIHelper_CreateJNIArgArray_mCA21BB6EB162E1E77E8F95812BD662EA078EDDBF,
	AndroidJNIHelper_DeleteJNIArgArray_m287B584251A89771CD7C767119A350BD6DDACCAB,
	AndroidJNIHelper_GetConstructorID_m06AB8A133FD78AE60E6B5871CBD24609B9444ED7,
	NULL,
	NULL,
	AndroidJNI_FindClass_mA0D17BF36250F96F40D8DCF193A7C65E6F6DED7F,
	AndroidJNI_FromReflectedMethod_m4483E987AEC5B258356E5A89F4C3865573AADFE6,
	AndroidJNI_ExceptionOccurred_m6C27C01B14483F99373608BF1A56CA53BA46F926,
	AndroidJNI_ExceptionClear_m90681289A6CEAF160DB188A3E2177F323D996F82,
	AndroidJNI_NewGlobalRef_m5F4875C8F71CF25DCC437D2EDB75320C487DB074,
	AndroidJNI_DeleteGlobalRef_m0420C00BACE4BD46DD58F8738DFD9EE8189F542A,
	AndroidJNI_NewWeakGlobalRef_m74933FB5C1E361F566A96B25CF096C770860CD94,
	AndroidJNI_DeleteWeakGlobalRef_m23C9808936212AC528658CB4989F15580BB0C734,
	AndroidJNI_NewLocalRef_mA95E1CDBA47E9CEC4D55BBA178F0ACF4219F6E29,
	AndroidJNI_DeleteLocalRef_m2A8137D15FDE9F781B13F71348FD5FFA1F9841BD,
	AndroidJNI_NewObject_mD058F016DBC3D58BF2A64EA84D6943052D01E8B1,
	AndroidJNI_GetObjectClass_mA8282FA341DF231C0ADD07DE0B0D0E5999EA0207,
	AndroidJNI_GetMethodID_mCB601A11C971557E2F89DD968224749BD71D2B3A,
	AndroidJNI_GetStaticMethodID_m46303AF2AAD855E623DFC9C341E848735B626A77,
	AndroidJNI_NewString_mF3FC7534344BDF4B4BD2B2DB5442B06E2402B23F,
	AndroidJNI_NewStringFromStr_mEEF9F3FF518F3CEEE81780A61DDEB0B93D3ED548,
	AndroidJNI_GetStringChars_m462C62C322F38797F05A818CEF5C8D235F1F6714,
	AndroidJNI_CallStringMethod_m932940262AEC9A8121916054C90D79866D29C547,
	AndroidJNI_CallObjectMethod_m059D1BE669D486F2A26B40D6B90BF157B84A3CA3,
	AndroidJNI_CallIntMethod_m5CE09EA0846BF49ABE3E23BC923710A0F1FF4787,
	AndroidJNI_CallBooleanMethod_m6556ACCEDD78DE903521F341072907C4EC90FC96,
	AndroidJNI_CallShortMethod_m889B967EB2D48E331692B199D2EDABACEC8D5F01,
	AndroidJNI_CallSByteMethod_m45D5ABB4DDFBFEFC6DB132FC2D8463C501F1E4A5,
	AndroidJNI_CallCharMethod_mEF6E65AB2EE0BFAA136878966C42FB21529CB91D,
	AndroidJNI_CallFloatMethod_m5BC422FC7D771A08DD18B443CBE3941ACD239FD9,
	AndroidJNI_CallDoubleMethod_m88A34942D1206EEE8BEA95475722D2E8FFFFC711,
	AndroidJNI_CallLongMethod_m2AF630255CC50CB6A875E4FC1E13023699504C6E,
	AndroidJNI_CallStaticStringMethod_m728910FCD2307FC8A06ACA204C6308896E1F9634,
	AndroidJNI_CallStaticObjectMethod_mD81C9407381F719A207F5AD038D38A1DDF181306,
	AndroidJNI_CallStaticIntMethod_mF3BBC45BEA5618BDE9E8C35CF86E4089CB366FAB,
	AndroidJNI_CallStaticBooleanMethod_m19B53E56531AEDB6735F1D5651E622E4E823EE92,
	AndroidJNI_CallStaticShortMethod_m7510F3205665CF3134DD91BAB86458A916B4FA67,
	AndroidJNI_CallStaticSByteMethod_m91B3565EC4E89DB5DD6994ED9DC03DC1506D9ABD,
	AndroidJNI_CallStaticCharMethod_mC17CFB28DA453858E2D5189C4A93985A5074ECAC,
	AndroidJNI_CallStaticFloatMethod_m50DD95A67820F5A3E3C62556600D985DA697889B,
	AndroidJNI_CallStaticDoubleMethod_m9396E74A4DC7D047134A5DCFFBB343651C1C46FC,
	AndroidJNI_CallStaticLongMethod_m2E00D7592B163630AF5352E89F6180F6B56B8278,
	AndroidJNI_CallStaticVoidMethod_mE1E41BEF150679746147820E058E034CCE9F5FB3,
	AndroidJNI_ToBooleanArray_m60F3CE17AE326BA244382C39F0FAE9F86DA1F206,
	AndroidJNI_ToByteArray_mA20FD81095A5C55B49F5362F586258D6E1361F14,
	AndroidJNI_ToSByteArray_m5E75BAD1F59BF0993F573E548837DB5BEFD136D0,
	AndroidJNI_ToCharArray_mA2081BFCF1F054F7AF1FF6C02DBCD3DDF842ACD1,
	AndroidJNI_ToShortArray_m5C720FF3C3E8A33E7F0679DEE1CF29279A3F6EE4,
	AndroidJNI_ToIntArray_m4F7B434E1B855ED0CCA21E5D3FE94BABCC246805,
	AndroidJNI_ToLongArray_mBE89CB90348200EFD4A8939241A030FF7FB3B205,
	AndroidJNI_ToFloatArray_m805231BFD408148D10ECB4B19935D49FD2E59E73,
	AndroidJNI_ToDoubleArray_m5365EB845635C82BAFC86696C6083F22A79F49EE,
	AndroidJNI_ToObjectArray_mED4ECAFBCB6517A46658F92FCCF2492ADE08C3B5,
	AndroidJNI_FromBooleanArray_m5EE3946B096CBAFCDED6E33AD0BEDF392CE3C2E3,
	AndroidJNI_FromByteArray_m2E5209DB888EB1CFD47E732AB5F565CEB351B766,
	AndroidJNI_FromSByteArray_m46D4FF95707BEC89FB35BADAC0D778D1F9FFE600,
	AndroidJNI_FromCharArray_mC965E533F95CD2ED4BE5DB99579D6C9723F9FFEF,
	AndroidJNI_FromShortArray_m155B1A19DC1AA710079277D8392ECC84578C095C,
	AndroidJNI_FromIntArray_m0139900B65713B2EC09EB03596157D39968E81BC,
	AndroidJNI_FromLongArray_mCFB950966DB71AE966C3CE5B8B2FC63BD874B3EC,
	AndroidJNI_FromFloatArray_mDC9E8A87B643677DB1CD67FB90EE6AC30A2352C5,
	AndroidJNI_FromDoubleArray_m069C4F1F762610BA916F674B3125A68634F27AB8,
	AndroidJNI_GetArrayLength_m67AF3E58A9CFD97E7934D2E63D0306865A78DA12,
	AndroidJNI_NewObjectArray_m8B0C45BD47F6563EA916E35BE26691DFA6482A51,
	AndroidJNI_GetObjectArrayElement_mDD7F2DC202FA14B8E5889755FB02B401C1127AD0,
	AndroidJNI_SetObjectArrayElement_m5D80CF792A1C492F97EC3378E36FFF458BAFD8D1,
	AndroidJNISafe_CheckException_mD1BB59188CDDCC2559F595CE1240E6BB12F1D546,
	AndroidJNISafe_DeleteGlobalRef_mC71D9B4DBED2AB66D49764253BA8DE912F731A40,
	AndroidJNISafe_DeleteWeakGlobalRef_m9B39A30D764938DC4C8D526321520701D77D34A7,
	AndroidJNISafe_DeleteLocalRef_m80503AA6C85CE46E8CE72C62215E1BE62964424D,
	AndroidJNISafe_NewString_m6D6411F7DACFD383054457D88C0F0F1F8AE0CFB9,
	AndroidJNISafe_GetStringChars_m21A07825755C0A9AF91F8248A1C98F861E26928F,
	AndroidJNISafe_GetObjectClass_m78626C2B107D46FA9276B6FD32D746EEB81E8D2D,
	AndroidJNISafe_GetStaticMethodID_mDD304107A2DCF7C4FFFC6E820361618693FCD8C7,
	AndroidJNISafe_GetMethodID_m4E480BAEFB37F467848EC9074C6917A2D8E853DC,
	AndroidJNISafe_FromReflectedMethod_mA0F291FDD88E4B0BD2242D9846833C696CF64F86,
	AndroidJNISafe_FindClass_m921B6BE5C8F1F1A4207761AD07A57C0D5F599DDE,
	AndroidJNISafe_NewObject_mCA783442B4DE3E0071D2C71DE69A655EF8538E2C,
	AndroidJNISafe_CallStaticVoidMethod_m965D8C47FDF1388EA6192108063B129C870B382F,
	AndroidJNISafe_CallStaticObjectMethod_mFF379E5F210AF38781F1FB59667AC39C4CFA5966,
	AndroidJNISafe_CallStaticStringMethod_mC5449583711986CFF9CCDAD3F8058D9842229B88,
	AndroidJNISafe_CallStaticCharMethod_m435C3A57BC14CCA2F459E1CE9D3E9F084353634C,
	AndroidJNISafe_CallStaticDoubleMethod_mDCA07255A15D31B20FFD77A795A7FD47C8661D1D,
	AndroidJNISafe_CallStaticFloatMethod_mCEF7855DF0530B27B6E0B4B1C1E78667FD80B2B6,
	AndroidJNISafe_CallStaticLongMethod_mA98EE656033866FC4DE05F3F815F76594FA18D84,
	AndroidJNISafe_CallStaticShortMethod_m134B1C6791FD9A09180ADF481475880F4F8B79A4,
	AndroidJNISafe_CallStaticSByteMethod_mC9057F28DC0C675701810414D19C7168A68F026D,
	AndroidJNISafe_CallStaticBooleanMethod_mF980739844CAA33E0E0ADA82F5177F91E39CCB75,
	AndroidJNISafe_CallStaticIntMethod_mE174E036EAB1034BA4DC107F534F0F7B6DA8FBC6,
	AndroidJNISafe_CallObjectMethod_m220EBB62A14A40DD5693A48E5787DE4636D051EA,
	AndroidJNISafe_CallStringMethod_mABFAE9A418A989676CB15D01E5971E431BFD4579,
	AndroidJNISafe_CallCharMethod_m4A39264614C8E7A9E2645F7C0E208062990A9D90,
	AndroidJNISafe_CallDoubleMethod_m53CDFD6982DECEB5F155858B4D0B8D7A06B426DD,
	AndroidJNISafe_CallFloatMethod_m95871A924AA515B19EEFD76FC5DABE3E2FAE4909,
	AndroidJNISafe_CallLongMethod_m6F9F122D99AB7C95774CE395A98153B705D07931,
	AndroidJNISafe_CallShortMethod_mDA06E47602A9F365C91DB7D3B78A699D8A48F861,
	AndroidJNISafe_CallSByteMethod_mA5011FBB030ABC0A47C34052A49A7BEBC1F9EDC0,
	AndroidJNISafe_CallBooleanMethod_m9B26AA2F5828D29D1F1BC3315BABE97F3614EE08,
	AndroidJNISafe_CallIntMethod_m1C01B0148542E93B661401AB695295F4DFB334A8,
	AndroidJNISafe_FromCharArray_mC1C728B67330FD610542B4C2D6B9759F78B2BD17,
	AndroidJNISafe_FromDoubleArray_mB752FB522CD25191E5C6AF8CEFA4553593F784A7,
	AndroidJNISafe_FromFloatArray_m97B7BC8546EC3F9CF0784D434D4AA41FBB409892,
	AndroidJNISafe_FromLongArray_m687FC548BFA4DC440379619E5C7CB56354E30D59,
	AndroidJNISafe_FromShortArray_m227116D8E01EE3568936FB93C97CAEE9062A0A35,
	AndroidJNISafe_FromByteArray_mAED5B8EEF34E268BB146A277842089C7FD8A06BB,
	AndroidJNISafe_FromSByteArray_m5825C71BA6941CDF25627AD77CDBE648CB322476,
	AndroidJNISafe_FromBooleanArray_m3F57F10FDDBA3DC358BEF7296F58D819C9EC3BDE,
	AndroidJNISafe_FromIntArray_m899EDC375E4983DCF33B5B72E2131DC06AA4B5F0,
	AndroidJNISafe_ToObjectArray_m0F776C4B1BA875104CCB8345797A9269A3EBCF07,
	AndroidJNISafe_ToCharArray_m8C8F076F9A471146F6BCF063F7415E89BC0FC801,
	AndroidJNISafe_ToDoubleArray_mCAF30FC9FA2947EBC680D89374A5296D775132A9,
	AndroidJNISafe_ToFloatArray_m15157B7C76CE04863F365E7052671AC87D8556E0,
	AndroidJNISafe_ToLongArray_m00D8D5A5D1B46639307AA78C5E4E7421EA0FF16A,
	AndroidJNISafe_ToShortArray_m3591547B05CEABD583A023C267091A536E3F925C,
	AndroidJNISafe_ToByteArray_m13141E44A84BDC2716432D09131984A4ADFC101F,
	AndroidJNISafe_ToSByteArray_mEFB80D7817A15C285872B8F3C1A9A1EDEA9ECC34,
	AndroidJNISafe_ToBooleanArray_m2E622CCA3AB1B19FE519F975391636CA7DECDAF7,
	AndroidJNISafe_ToIntArray_mA46A79AFCB3909BB90FFF2D20EFDA042E6A4DE97,
	AndroidJNISafe_GetObjectArrayElement_m515AF7717FD44C40A5FFFD6E50DFCD65A35B8FF5,
	AndroidJNISafe_GetArrayLength_mB5F7260E652BE95FE9237A47C1E1597306B462C3,
};
static const int32_t s_InvokerIndices[190] = 
{
	1502,
	3311,
	1504,
	3226,
	2664,
	3311,
	4834,
	3311,
	2680,
	2680,
	2680,
	3311,
	1174,
	1174,
	3226,
	3208,
	5107,
	1504,
	3311,
	3208,
	3208,
	0,
	0,
	2680,
	1504,
	2664,
	3311,
	3311,
	2622,
	0,
	0,
	4863,
	4863,
	0,
	3208,
	3208,
	2680,
	2680,
	2664,
	4733,
	4357,
	4087,
	4087,
	4470,
	3821,
	4469,
	4244,
	5107,
	4470,
	4834,
	4086,
	4864,
	4864,
	4864,
	4864,
	4636,
	4834,
	0,
	4470,
	0,
	4470,
	3821,
	3821,
	4864,
	4864,
	0,
	4470,
	3821,
	4834,
	4834,
	4864,
	4636,
	4470,
	0,
	0,
	4834,
	4833,
	5076,
	5107,
	4833,
	5001,
	4833,
	5001,
	4833,
	5001,
	4083,
	4833,
	4084,
	4084,
	4834,
	4834,
	4863,
	4108,
	4083,
	4054,
	3990,
	4035,
	4139,
	4163,
	4145,
	4028,
	4077,
	4108,
	4083,
	4054,
	3990,
	4035,
	4139,
	4163,
	4145,
	4028,
	4077,
	4242,
	4834,
	4834,
	4834,
	4834,
	4834,
	4834,
	4834,
	4834,
	4834,
	4471,
	4863,
	4863,
	4863,
	4863,
	4863,
	4863,
	4863,
	4863,
	4863,
	4806,
	4082,
	4468,
	4240,
	5107,
	5001,
	5001,
	5001,
	4834,
	4863,
	4833,
	4084,
	4084,
	4833,
	4834,
	4083,
	4242,
	4083,
	4108,
	4163,
	4028,
	4145,
	4077,
	4035,
	4139,
	3990,
	4054,
	4083,
	4108,
	4163,
	4028,
	4145,
	4077,
	4035,
	4139,
	3990,
	4054,
	4863,
	4863,
	4863,
	4863,
	4863,
	4863,
	4863,
	4863,
	4863,
	4471,
	4834,
	4834,
	4834,
	4834,
	4834,
	4834,
	4834,
	4834,
	4834,
	4468,
	4806,
};
static const Il2CppTokenRangePair s_rgctxIndices[10] = 
{
	{ 0x06000016, { 0, 1 } },
	{ 0x06000017, { 1, 1 } },
	{ 0x0600001E, { 2, 4 } },
	{ 0x0600001F, { 6, 4 } },
	{ 0x06000022, { 10, 2 } },
	{ 0x0600003A, { 12, 2 } },
	{ 0x0600003C, { 14, 1 } },
	{ 0x06000042, { 15, 1 } },
	{ 0x0600004A, { 16, 1 } },
	{ 0x0600004B, { 17, 1 } },
};
extern const uint32_t g_rgctx_AndroidJavaObject__Call_TisReturnType_t7C9CEFF53F7F785E3B0A2AA52BF0599DB9E4C7A7_m53C8581E9FA8AB194F9919FD0B5F910D4D0EDEDF;
extern const uint32_t g_rgctx_AndroidJavaObject__CallStatic_TisReturnType_t94E13999E45FF70AA5DA5E427955FC4E439412B2_m7F6D9361C675DD63CF53A9BE7588D79625F85B4D;
extern const uint32_t g_rgctx_AndroidJNIHelper_GetMethodID_TisReturnType_t0FD1385ACD92B5652F803E183304929EDB7632D9_m7FA36234B45F9903C0B0CDEBE1B54DCD39A13C72;
extern const uint32_t g_rgctx_ReturnType_t0FD1385ACD92B5652F803E183304929EDB7632D9;
extern const uint32_t g_rgctx_ReturnType_t0FD1385ACD92B5652F803E183304929EDB7632D9;
extern const uint32_t g_rgctx_AndroidJavaObject_FromJavaArrayDeleteLocalRef_TisReturnType_t0FD1385ACD92B5652F803E183304929EDB7632D9_m5ED9B59C80B23E79BB4230605BCE9D3A137F981E;
extern const uint32_t g_rgctx_AndroidJNIHelper_GetMethodID_TisReturnType_t2DAB0875DF34A21B532F695F9B7329A0B5BBCB27_m41D8B27438C044781B1CAEFF8C3D98E9E6B21818;
extern const uint32_t g_rgctx_ReturnType_t2DAB0875DF34A21B532F695F9B7329A0B5BBCB27;
extern const uint32_t g_rgctx_ReturnType_t2DAB0875DF34A21B532F695F9B7329A0B5BBCB27;
extern const uint32_t g_rgctx_AndroidJavaObject_FromJavaArrayDeleteLocalRef_TisReturnType_t2DAB0875DF34A21B532F695F9B7329A0B5BBCB27_mB3A1E6CF7D03BB9DDF35E7E2BE4C29EA2F36C17F;
extern const uint32_t g_rgctx_AndroidJNIHelper_ConvertFromJNIArray_TisReturnType_t6F6A8AAD1934478A88473188C291F7CEEE555E73_m4B892F7AD0542C392F743019B7218AFDAFEABD68;
extern const uint32_t g_rgctx_ReturnType_t6F6A8AAD1934478A88473188C291F7CEEE555E73;
extern const uint32_t g_rgctx_ArrayType_t39F42761AC90C900B8A48509E901BA6E97D3879B;
extern const uint32_t g_rgctx_ArrayType_t39F42761AC90C900B8A48509E901BA6E97D3879B;
extern const uint32_t g_rgctx__AndroidJNIHelper_GetSignature_TisReturnType_tEC17892DFE45E2A034D63503275043AAE3B9599D_m36DEB041CA570208002E5FB9A443601A54460C73;
extern const uint32_t g_rgctx_ReturnType_tBDDF22167069A86BB26C0100BBDE8BF7FE746984;
extern const uint32_t g_rgctx__AndroidJNIHelper_ConvertFromJNIArray_TisArrayType_t4E16470C69F824CCEAFF1C35E3BD65E700433C8D_m79E24A56A47AA341285459B81B432B0DB4BB5E00;
extern const uint32_t g_rgctx__AndroidJNIHelper_GetMethodID_TisReturnType_t9337B47B2F29B15EC319F165264468E864AE5381_mE5379E80F384020D4EE22BD44DE9FF5766BA175B;
static const Il2CppRGCTXDefinition s_rgctxValues[18] = 
{
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJavaObject__Call_TisReturnType_t7C9CEFF53F7F785E3B0A2AA52BF0599DB9E4C7A7_m53C8581E9FA8AB194F9919FD0B5F910D4D0EDEDF },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJavaObject__CallStatic_TisReturnType_t94E13999E45FF70AA5DA5E427955FC4E439412B2_m7F6D9361C675DD63CF53A9BE7588D79625F85B4D },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJNIHelper_GetMethodID_TisReturnType_t0FD1385ACD92B5652F803E183304929EDB7632D9_m7FA36234B45F9903C0B0CDEBE1B54DCD39A13C72 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_ReturnType_t0FD1385ACD92B5652F803E183304929EDB7632D9 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ReturnType_t0FD1385ACD92B5652F803E183304929EDB7632D9 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJavaObject_FromJavaArrayDeleteLocalRef_TisReturnType_t0FD1385ACD92B5652F803E183304929EDB7632D9_m5ED9B59C80B23E79BB4230605BCE9D3A137F981E },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJNIHelper_GetMethodID_TisReturnType_t2DAB0875DF34A21B532F695F9B7329A0B5BBCB27_m41D8B27438C044781B1CAEFF8C3D98E9E6B21818 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_ReturnType_t2DAB0875DF34A21B532F695F9B7329A0B5BBCB27 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ReturnType_t2DAB0875DF34A21B532F695F9B7329A0B5BBCB27 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJavaObject_FromJavaArrayDeleteLocalRef_TisReturnType_t2DAB0875DF34A21B532F695F9B7329A0B5BBCB27_mB3A1E6CF7D03BB9DDF35E7E2BE4C29EA2F36C17F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_AndroidJNIHelper_ConvertFromJNIArray_TisReturnType_t6F6A8AAD1934478A88473188C291F7CEEE555E73_m4B892F7AD0542C392F743019B7218AFDAFEABD68 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ReturnType_t6F6A8AAD1934478A88473188C291F7CEEE555E73 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_ArrayType_t39F42761AC90C900B8A48509E901BA6E97D3879B },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ArrayType_t39F42761AC90C900B8A48509E901BA6E97D3879B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx__AndroidJNIHelper_GetSignature_TisReturnType_tEC17892DFE45E2A034D63503275043AAE3B9599D_m36DEB041CA570208002E5FB9A443601A54460C73 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_ReturnType_tBDDF22167069A86BB26C0100BBDE8BF7FE746984 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx__AndroidJNIHelper_ConvertFromJNIArray_TisArrayType_t4E16470C69F824CCEAFF1C35E3BD65E700433C8D_m79E24A56A47AA341285459B81B432B0DB4BB5E00 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx__AndroidJNIHelper_GetMethodID_TisReturnType_t9337B47B2F29B15EC319F165264468E864AE5381_mE5379E80F384020D4EE22BD44DE9FF5766BA175B },
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_UnityEngine_AndroidJNIModule_CodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_AndroidJNIModule_CodeGenModule = 
{
	"UnityEngine.AndroidJNIModule.dll",
	190,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	10,
	s_rgctxIndices,
	18,
	s_rgctxValues,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
