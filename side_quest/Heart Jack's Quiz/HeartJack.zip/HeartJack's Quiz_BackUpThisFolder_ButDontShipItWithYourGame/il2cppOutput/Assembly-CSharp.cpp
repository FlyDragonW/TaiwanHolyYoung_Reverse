﻿#include "pch-cpp.hpp"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <limits>
#include <stdint.h>


template <typename T1>
struct VirtualActionInvoker1
{
	typedef void (*Action)(void*, T1, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeObject* obj, T1 p1)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		((Action)invokeData.methodPtr)(obj, p1, invokeData.method);
	}
};

// UnityEngine.UI.CoroutineTween.TweenRunner`1<UnityEngine.UI.CoroutineTween.ColorTween>
struct TweenRunner_1_t5BB0582F926E75E2FE795492679A6CF55A4B4BC4;
// System.Byte[]
struct ByteU5BU5D_tA6237BF417AE52AD70CFB4EF24A7A82613DF9031;
// UnityEngine.GameObject[]
struct GameObjectU5BU5D_tFF67550DFCE87096D7A3734EA15B75896B2722CF;
// System.String[]
struct StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248;
// UnityEngine.UI.Text[]
struct TextU5BU5D_t1D476A037C4542F053D17ADAFA2723F311F9A353;
// UnityEngine.UIVertex[]
struct UIVertexU5BU5D_tBC532486B45D071A520751A90E819C77BA4E3D2F;
// UnityEngine.Vector2[]
struct Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA;
// UnityEngine.Vector3[]
struct Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C;
// UnityEngine.Canvas
struct Canvas_t2DB4CEFDFF732884866C83F11ABF75F5AE8FFB26;
// UnityEngine.CanvasRenderer
struct CanvasRenderer_tAB9A55A976C4E3B2B37D0CE5616E5685A8B43860;
// UnityEngine.UI.FontData
struct FontData_tB8E562846C6CB59C43260F69AE346B9BF3157224;
// UnityEngine.GameObject
struct GameObject_t76FEDD663AB33C991A9C9A23129337651094216F;
// UnityEngine.Material
struct Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3;
// UnityEngine.Mesh
struct Mesh_t6D9C539763A09BC2B12AEAEF36F6DFFC98AE63D4;
// UnityEngine.MonoBehaviour
struct MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71;
// UnityEngine.Object
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C;
// UnityEngine.UI.RectMask2D
struct RectMask2D_tACF92BE999C791A665BD1ADEABF5BCEB82846670;
// UnityEngine.RectTransform
struct RectTransform_t6C5DA5E41A89E0F488B001E45E58963480E543A5;
// System.String
struct String_t;
// UnityEngine.UI.Text
struct Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62;
// UnityEngine.TextGenerator
struct TextGenerator_t85D00417640A53953556C01F9D4E7DDE1ABD8FEC;
// UnityEngine.Texture2D
struct Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4;
// UnityEngine.Events.UnityAction
struct UnityAction_t11A1F3B953B365C072A5DCC32677EE1796A962A7;
// UnityEngine.UI.VertexHelper
struct VertexHelper_tB905FCB02AE67CBEE5F265FE37A5938FC5D136FE;
// System.Void
struct Void_t4861ACF8F4594C3437BB48B6E56783494B843915;
// main
struct main_t1A11BBC717193895305089E991DE21F2263A0673;
// UnityEngine.UI.MaskableGraphic/CullStateChangedEvent
struct CullStateChangedEvent_t6073CD0D951EC1256BF74B8F9107D68FC89B99B8;

IL2CPP_EXTERN_C RuntimeClass* Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* SceneManager_tA0EF56A88ACA4A15731AF7FDC10A869FA4C698FA_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C String_t* _stringLiteral0EBD646B60E1C3FCE0203770591ED3C3D63537DC;
IL2CPP_EXTERN_C String_t* _stringLiteral180D18640B3EF3AEEB0F2B16221B1DD75FC1565D;
IL2CPP_EXTERN_C String_t* _stringLiteral2064F80F811DB79A33C4E51C10221454E30C74AE;
IL2CPP_EXTERN_C String_t* _stringLiteral21ED4C7AF50D987589A9029FC0422151BE3A0FC2;
IL2CPP_EXTERN_C String_t* _stringLiteral262A11B14765132132BB36C155D62CD085035B1E;
IL2CPP_EXTERN_C String_t* _stringLiteral3D714DD3E8E77A697EF557E85ED2B014A96328C5;
IL2CPP_EXTERN_C String_t* _stringLiteral3F5BA7FB1F7E7D244143237CC72674F496DF7066;
IL2CPP_EXTERN_C String_t* _stringLiteral463DF0D1B4A10955AED259E5B64FCE911CFD2144;
IL2CPP_EXTERN_C String_t* _stringLiteral49A7EA21ECB328D154FA2262BB41626D795F4D90;
IL2CPP_EXTERN_C String_t* _stringLiteral4E1AB9B7A40400CB752932191375E56DCD9B66E4;
IL2CPP_EXTERN_C String_t* _stringLiteral68D6B38EFEA69B10C9C23CE03FE8B226C1423DD6;
IL2CPP_EXTERN_C String_t* _stringLiteral7454695E25D304C65D0C1333D8008E862569CAE9;
IL2CPP_EXTERN_C String_t* _stringLiteral75B387A7897CE7621C215035B89C223031380111;
IL2CPP_EXTERN_C String_t* _stringLiteral772B560622741F096D2A869E0F4F4CDFAF4AF569;
IL2CPP_EXTERN_C String_t* _stringLiteral7A84FD2DD90C89AF3B31456B65720D0471E8EC32;
IL2CPP_EXTERN_C String_t* _stringLiteral7BE9A66971DEC7B6BC132AEFD4786EA2AA539505;
IL2CPP_EXTERN_C String_t* _stringLiteral88FD92D554D8DD49EDFAAF0D74D8F6FAC8BE1E80;
IL2CPP_EXTERN_C String_t* _stringLiteral8DAE88EAE46501EE3F1AF9B2923FE04DE343E4B3;
IL2CPP_EXTERN_C String_t* _stringLiteral9353229FEAE90F69FD00B32309FF7495D98F2ACE;
IL2CPP_EXTERN_C String_t* _stringLiteral9755BDFEB5F9A49D48C9DE1EB7313122568D3332;
IL2CPP_EXTERN_C String_t* _stringLiteralAE062B38E5AE5EB9EE0CDC807BBBFECEF216B283;
IL2CPP_EXTERN_C String_t* _stringLiteralB16CF3324CA15FF0851B0F99DD86AC638C3E0CAE;
IL2CPP_EXTERN_C String_t* _stringLiteralB9C8705A23DE64A7C23E91CAFA403A15FCF82D21;
IL2CPP_EXTERN_C String_t* _stringLiteralBD7EDB0FB4B6D1A18FC63542875F06A4BA99FBF6;
IL2CPP_EXTERN_C String_t* _stringLiteralCB0B38E085DB4D82F1F8E2D5FFA87679899F8E27;
IL2CPP_EXTERN_C String_t* _stringLiteralE91FE173F59B063D620A934CE1A010F2B114C1F3;
IL2CPP_EXTERN_C String_t* _stringLiteralEA2E8F12196B3367A735F4C71E698E73DDBB43BD;
IL2CPP_EXTERN_C String_t* _stringLiteralEF420ABFDDBDA7B9EE665D85EF62E4A437554003;
IL2CPP_EXTERN_C String_t* _stringLiteralF944DCD635F9801F7AC90A407FBC479964DEC024;

struct GameObjectU5BU5D_tFF67550DFCE87096D7A3734EA15B75896B2722CF;
struct StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248;
struct TextU5BU5D_t1D476A037C4542F053D17ADAFA2723F311F9A353;

IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct U3CModuleU3E_tBB65183F1134474D09FF49B95625D25472B9BA8B 
{
};
struct Il2CppArrayBounds;

// System.String
struct String_t  : public RuntimeObject
{
	// System.Int32 System.String::_stringLength
	int32_t ____stringLength_4;
	// System.Char System.String::_firstChar
	Il2CppChar ____firstChar_5;
};

struct String_t_StaticFields
{
	// System.String System.String::Empty
	String_t* ___Empty_6;
};

// System.ValueType
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F  : public RuntimeObject
{
};
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F_marshaled_com
{
};

// System.Boolean
struct Boolean_t09A6377A54BE2F9E6985A8149F19234FD7DDFE22 
{
	// System.Boolean System.Boolean::m_value
	bool ___m_value_0;
};

struct Boolean_t09A6377A54BE2F9E6985A8149F19234FD7DDFE22_StaticFields
{
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_5;
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_6;
};

// System.Char
struct Char_t521A6F19B456D956AF452D926C32709DC03D6B17 
{
	// System.Char System.Char::m_value
	Il2CppChar ___m_value_0;
};

struct Char_t521A6F19B456D956AF452D926C32709DC03D6B17_StaticFields
{
	// System.Byte[] System.Char::s_categoryForLatin1
	ByteU5BU5D_tA6237BF417AE52AD70CFB4EF24A7A82613DF9031* ___s_categoryForLatin1_3;
};

// UnityEngine.Color
struct Color_tD001788D726C3A7F1379BEED0260B9591F440C1F 
{
	// System.Single UnityEngine.Color::r
	float ___r_0;
	// System.Single UnityEngine.Color::g
	float ___g_1;
	// System.Single UnityEngine.Color::b
	float ___b_2;
	// System.Single UnityEngine.Color::a
	float ___a_3;
};

// System.Double
struct Double_tE150EF3D1D43DEE85D533810AB4C742307EEDE5F 
{
	// System.Double System.Double::m_value
	double ___m_value_0;
};

// System.Int32
struct Int32_t680FF22E76F6EFAD4375103CBBFFA0421349384C 
{
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_0;
};

// System.IntPtr
struct IntPtr_t 
{
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;
};

struct IntPtr_t_StaticFields
{
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;
};

// System.Single
struct Single_t4530F2FF86FCB0DC29F35385CA1BD21BE294761C 
{
	// System.Single System.Single::m_value
	float ___m_value_0;
};

// UnityEngine.Vector4
struct Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 
{
	// System.Single UnityEngine.Vector4::x
	float ___x_1;
	// System.Single UnityEngine.Vector4::y
	float ___y_2;
	// System.Single UnityEngine.Vector4::z
	float ___z_3;
	// System.Single UnityEngine.Vector4::w
	float ___w_4;
};

struct Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3_StaticFields
{
	// UnityEngine.Vector4 UnityEngine.Vector4::zeroVector
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___zeroVector_5;
	// UnityEngine.Vector4 UnityEngine.Vector4::oneVector
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___oneVector_6;
	// UnityEngine.Vector4 UnityEngine.Vector4::positiveInfinityVector
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___positiveInfinityVector_7;
	// UnityEngine.Vector4 UnityEngine.Vector4::negativeInfinityVector
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___negativeInfinityVector_8;
};

// System.Void
struct Void_t4861ACF8F4594C3437BB48B6E56783494B843915 
{
	union
	{
		struct
		{
		};
		uint8_t Void_t4861ACF8F4594C3437BB48B6E56783494B843915__padding[1];
	};
};

// UnityEngine.Object
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C  : public RuntimeObject
{
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	intptr_t ___m_CachedPtr_0;
};

struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_StaticFields
{
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;
};
// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};

// UnityEngine.Component
struct Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3  : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C
{
};

// UnityEngine.GameObject
struct GameObject_t76FEDD663AB33C991A9C9A23129337651094216F  : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C
{
};

// UnityEngine.Behaviour
struct Behaviour_t01970CFBBA658497AE30F311C447DB0440BAB7FA  : public Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3
{
};

// UnityEngine.MonoBehaviour
struct MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71  : public Behaviour_t01970CFBBA658497AE30F311C447DB0440BAB7FA
{
};

// UnityEngine.EventSystems.UIBehaviour
struct UIBehaviour_tB9D4295827BD2EEDEF0749200C6CA7090C742A9D  : public MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71
{
};

// main
struct main_t1A11BBC717193895305089E991DE21F2263A0673  : public MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71
{
	// UnityEngine.GameObject main::startBtn
	GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* ___startBtn_4;
	// UnityEngine.GameObject main::input
	GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* ___input_5;
	// UnityEngine.GameObject main::lose
	GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* ___lose_6;
	// UnityEngine.GameObject main::joker
	GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* ___joker_7;
	// UnityEngine.GameObject[] main::btns
	GameObjectU5BU5D_tFF67550DFCE87096D7A3734EA15B75896B2722CF* ___btns_8;
	// UnityEngine.UI.Text[] main::texts
	TextU5BU5D_t1D476A037C4542F053D17ADAFA2723F311F9A353* ___texts_9;
	// UnityEngine.UI.Text main::title
	Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* ___title_10;
	// UnityEngine.UI.Text main::timerText
	Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* ___timerText_11;
	// System.Int32 main::questionIndex
	int32_t ___questionIndex_12;
	// System.Single main::timer
	float ___timer_13;
	// System.Boolean main::isPlaying
	bool ___isPlaying_14;
	// System.String main::playerName
	String_t* ___playerName_15;
	// System.Int32 main::finalAnswer
	int32_t ___finalAnswer_16;
	// System.String main::answer
	String_t* ___answer_17;
};

// UnityEngine.UI.Graphic
struct Graphic_tCBFCA4585A19E2B75465AECFEAC43F4016BF7931  : public UIBehaviour_tB9D4295827BD2EEDEF0749200C6CA7090C742A9D
{
	// UnityEngine.Material UnityEngine.UI.Graphic::m_Material
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___m_Material_6;
	// UnityEngine.Color UnityEngine.UI.Graphic::m_Color
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___m_Color_7;
	// System.Boolean UnityEngine.UI.Graphic::m_SkipLayoutUpdate
	bool ___m_SkipLayoutUpdate_8;
	// System.Boolean UnityEngine.UI.Graphic::m_SkipMaterialUpdate
	bool ___m_SkipMaterialUpdate_9;
	// System.Boolean UnityEngine.UI.Graphic::m_RaycastTarget
	bool ___m_RaycastTarget_10;
	// UnityEngine.Vector4 UnityEngine.UI.Graphic::m_RaycastPadding
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___m_RaycastPadding_11;
	// UnityEngine.RectTransform UnityEngine.UI.Graphic::m_RectTransform
	RectTransform_t6C5DA5E41A89E0F488B001E45E58963480E543A5* ___m_RectTransform_12;
	// UnityEngine.CanvasRenderer UnityEngine.UI.Graphic::m_CanvasRenderer
	CanvasRenderer_tAB9A55A976C4E3B2B37D0CE5616E5685A8B43860* ___m_CanvasRenderer_13;
	// UnityEngine.Canvas UnityEngine.UI.Graphic::m_Canvas
	Canvas_t2DB4CEFDFF732884866C83F11ABF75F5AE8FFB26* ___m_Canvas_14;
	// System.Boolean UnityEngine.UI.Graphic::m_VertsDirty
	bool ___m_VertsDirty_15;
	// System.Boolean UnityEngine.UI.Graphic::m_MaterialDirty
	bool ___m_MaterialDirty_16;
	// UnityEngine.Events.UnityAction UnityEngine.UI.Graphic::m_OnDirtyLayoutCallback
	UnityAction_t11A1F3B953B365C072A5DCC32677EE1796A962A7* ___m_OnDirtyLayoutCallback_17;
	// UnityEngine.Events.UnityAction UnityEngine.UI.Graphic::m_OnDirtyVertsCallback
	UnityAction_t11A1F3B953B365C072A5DCC32677EE1796A962A7* ___m_OnDirtyVertsCallback_18;
	// UnityEngine.Events.UnityAction UnityEngine.UI.Graphic::m_OnDirtyMaterialCallback
	UnityAction_t11A1F3B953B365C072A5DCC32677EE1796A962A7* ___m_OnDirtyMaterialCallback_19;
	// UnityEngine.Mesh UnityEngine.UI.Graphic::m_CachedMesh
	Mesh_t6D9C539763A09BC2B12AEAEF36F6DFFC98AE63D4* ___m_CachedMesh_22;
	// UnityEngine.Vector2[] UnityEngine.UI.Graphic::m_CachedUvs
	Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA* ___m_CachedUvs_23;
	// UnityEngine.UI.CoroutineTween.TweenRunner`1<UnityEngine.UI.CoroutineTween.ColorTween> UnityEngine.UI.Graphic::m_ColorTweenRunner
	TweenRunner_1_t5BB0582F926E75E2FE795492679A6CF55A4B4BC4* ___m_ColorTweenRunner_24;
	// System.Boolean UnityEngine.UI.Graphic::<useLegacyMeshGeneration>k__BackingField
	bool ___U3CuseLegacyMeshGenerationU3Ek__BackingField_25;
};

struct Graphic_tCBFCA4585A19E2B75465AECFEAC43F4016BF7931_StaticFields
{
	// UnityEngine.Material UnityEngine.UI.Graphic::s_DefaultUI
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___s_DefaultUI_4;
	// UnityEngine.Texture2D UnityEngine.UI.Graphic::s_WhiteTexture
	Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* ___s_WhiteTexture_5;
	// UnityEngine.Mesh UnityEngine.UI.Graphic::s_Mesh
	Mesh_t6D9C539763A09BC2B12AEAEF36F6DFFC98AE63D4* ___s_Mesh_20;
	// UnityEngine.UI.VertexHelper UnityEngine.UI.Graphic::s_VertexHelper
	VertexHelper_tB905FCB02AE67CBEE5F265FE37A5938FC5D136FE* ___s_VertexHelper_21;
};

// UnityEngine.UI.MaskableGraphic
struct MaskableGraphic_tFC5B6BE351C90DE53744DF2A70940242774B361E  : public Graphic_tCBFCA4585A19E2B75465AECFEAC43F4016BF7931
{
	// System.Boolean UnityEngine.UI.MaskableGraphic::m_ShouldRecalculateStencil
	bool ___m_ShouldRecalculateStencil_26;
	// UnityEngine.Material UnityEngine.UI.MaskableGraphic::m_MaskMaterial
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___m_MaskMaterial_27;
	// UnityEngine.UI.RectMask2D UnityEngine.UI.MaskableGraphic::m_ParentMask
	RectMask2D_tACF92BE999C791A665BD1ADEABF5BCEB82846670* ___m_ParentMask_28;
	// System.Boolean UnityEngine.UI.MaskableGraphic::m_Maskable
	bool ___m_Maskable_29;
	// System.Boolean UnityEngine.UI.MaskableGraphic::m_IsMaskingGraphic
	bool ___m_IsMaskingGraphic_30;
	// System.Boolean UnityEngine.UI.MaskableGraphic::m_IncludeForMasking
	bool ___m_IncludeForMasking_31;
	// UnityEngine.UI.MaskableGraphic/CullStateChangedEvent UnityEngine.UI.MaskableGraphic::m_OnCullStateChanged
	CullStateChangedEvent_t6073CD0D951EC1256BF74B8F9107D68FC89B99B8* ___m_OnCullStateChanged_32;
	// System.Boolean UnityEngine.UI.MaskableGraphic::m_ShouldRecalculate
	bool ___m_ShouldRecalculate_33;
	// System.Int32 UnityEngine.UI.MaskableGraphic::m_StencilValue
	int32_t ___m_StencilValue_34;
	// UnityEngine.Vector3[] UnityEngine.UI.MaskableGraphic::m_Corners
	Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* ___m_Corners_35;
};

// UnityEngine.UI.Text
struct Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62  : public MaskableGraphic_tFC5B6BE351C90DE53744DF2A70940242774B361E
{
	// UnityEngine.UI.FontData UnityEngine.UI.Text::m_FontData
	FontData_tB8E562846C6CB59C43260F69AE346B9BF3157224* ___m_FontData_36;
	// System.String UnityEngine.UI.Text::m_Text
	String_t* ___m_Text_37;
	// UnityEngine.TextGenerator UnityEngine.UI.Text::m_TextCache
	TextGenerator_t85D00417640A53953556C01F9D4E7DDE1ABD8FEC* ___m_TextCache_38;
	// UnityEngine.TextGenerator UnityEngine.UI.Text::m_TextCacheForLayout
	TextGenerator_t85D00417640A53953556C01F9D4E7DDE1ABD8FEC* ___m_TextCacheForLayout_39;
	// System.Boolean UnityEngine.UI.Text::m_DisableFontTextureRebuiltCallback
	bool ___m_DisableFontTextureRebuiltCallback_41;
	// UnityEngine.UIVertex[] UnityEngine.UI.Text::m_TempVerts
	UIVertexU5BU5D_tBC532486B45D071A520751A90E819C77BA4E3D2F* ___m_TempVerts_42;
};

struct Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62_StaticFields
{
	// UnityEngine.Material UnityEngine.UI.Text::s_DefaultText
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___s_DefaultText_40;
};
#ifdef __clang__
#pragma clang diagnostic pop
#endif
// UnityEngine.GameObject[]
struct GameObjectU5BU5D_tFF67550DFCE87096D7A3734EA15B75896B2722CF  : public RuntimeArray
{
	ALIGN_FIELD (8) GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* m_Items[1];

	inline GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline GameObject_t76FEDD663AB33C991A9C9A23129337651094216F** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline GameObject_t76FEDD663AB33C991A9C9A23129337651094216F** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};
// UnityEngine.UI.Text[]
struct TextU5BU5D_t1D476A037C4542F053D17ADAFA2723F311F9A353  : public RuntimeArray
{
	ALIGN_FIELD (8) Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* m_Items[1];

	inline Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};
// System.String[]
struct StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248  : public RuntimeArray
{
	ALIGN_FIELD (8) String_t* m_Items[1];

	inline String_t* GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline String_t** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, String_t* value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline String_t* GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline String_t** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, String_t* value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};



// System.Single UnityEngine.Time::get_deltaTime()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float Time_get_deltaTime_m7AB6BFA101D83E1D8F2EF3D5A128AEE9DDBF1A6D (const RuntimeMethod* method) ;
// System.String System.Int32::ToString()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* Int32_ToString_m030E01C24E294D6762FB0B6F37CB541581F55CA5 (int32_t* __this, const RuntimeMethod* method) ;
// System.Void main::LOSE()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void main_LOSE_m1B99A3FCEF01A21F4E58404FCEC1FA6C46553B56 (main_t1A11BBC717193895305089E991DE21F2263A0673* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.Time::set_timeScale(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Time_set_timeScale_mD6CAA4968D796C4AF198ACFB2267BDBD06DB349C (float ___value0, const RuntimeMethod* method) ;
// System.Void UnityEngine.GameObject::SetActive(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GameObject_SetActive_m638E92E1E75E519E5B24CF150B08CA8E0CDFAB92 (GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* __this, bool ___value0, const RuntimeMethod* method) ;
// System.Void UnityEngine.UI.Text::set_fontSize(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Text_set_fontSize_m426338B0A2CDA58609028FFD471EF5F2C9F364D4 (Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* __this, int32_t ___value0, const RuntimeMethod* method) ;
// System.Void main::UpdateQuestion()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void main_UpdateQuestion_mE85E701A382F726FED5FDF3A4D7FD95280030818 (main_t1A11BBC717193895305089E991DE21F2263A0673* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.SceneManagement.SceneManager::LoadScene(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SceneManager_LoadScene_mE00D17D79AD74B307F913BBF296A36115548DB6D (int32_t ___sceneBuildIndex0, const RuntimeMethod* method) ;
// System.Char System.String::get_Chars(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Il2CppChar String_get_Chars_mC49DF0CD2D3BE7BE97B3AD9C995BE3094F8E36D3 (String_t* __this, int32_t ___index0, const RuntimeMethod* method) ;
// System.Double System.Char::GetNumericValue(System.Char)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR double Char_GetNumericValue_mC6F88D2867A2D6EAFB9399277E2A5406CDBB0D96 (Il2CppChar ___c0, const RuntimeMethod* method) ;
// System.Void main::WIN()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void main_WIN_m4B6F896DEC0EC766DAA2E9C8685861AE9F0EC6A7 (main_t1A11BBC717193895305089E991DE21F2263A0673* __this, const RuntimeMethod* method) ;
// System.Int32 System.String::get_Length()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t String_get_Length_m42625D67623FA5CC7A44D47425CE86FB946542D2_inline (String_t* __this, const RuntimeMethod* method) ;
// System.Boolean System.Char::IsNumber(System.Char)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Char_IsNumber_mDC791095BD939D5BC25410006FB6619CB77C2716 (Il2CppChar ___c0, const RuntimeMethod* method) ;
// System.Int32 main::secret(System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t main_secret_m4A232F0CFBFF68EA2BC226040CD9976DF0059172 (main_t1A11BBC717193895305089E991DE21F2263A0673* __this, int32_t ___x0, int32_t ___y1, const RuntimeMethod* method) ;
// System.String System.Char::ToString()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* Char_ToString_m2A308731F9577C06AF3C0901234E2EAC8327410C (Il2CppChar* __this, const RuntimeMethod* method) ;
// System.String System.String::Concat(System.String[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Concat_m6B0734B65813C8EA093D78E5C2D16534EB6FE8C0 (StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248* ___values0, const RuntimeMethod* method) ;
// System.Boolean System.String::op_Equality(System.String,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool String_op_Equality_m0D685A924E5CD78078F248ED1726DA5A9D7D6AC0 (String_t* ___a0, String_t* ___b1, const RuntimeMethod* method) ;
// System.String UnityEngine.Object::get_name()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* Object_get_name_mAC2F6B897CF1303BA4249B4CB55271AFACBB6392 (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.MonoBehaviour::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MonoBehaviour__ctor_m592DB0105CA0BC97AA1C5F4AD27B12D68A3B7C1E (MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71* __this, const RuntimeMethod* method) ;
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void main::ReadName(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void main_ReadName_mEC30A290A6F87931FA5869E3BF6E6F0FFE539DE8 (main_t1A11BBC717193895305089E991DE21F2263A0673* __this, String_t* ___s0, const RuntimeMethod* method) 
{
	{
		// playerName = s;
		String_t* L_0 = ___s0;
		__this->___playerName_15 = L_0;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___playerName_15), (void*)L_0);
		// }
		return;
	}
}
// System.Void main::Update()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void main_Update_m8A9D6818CB69459A554B68231329A0100C1D2830 (main_t1A11BBC717193895305089E991DE21F2263A0673* __this, const RuntimeMethod* method) 
{
	int32_t V_0 = 0;
	{
		// if (isPlaying)
		bool L_0 = __this->___isPlaying_14;
		if (!L_0)
		{
			goto IL_0047;
		}
	}
	{
		// timer -= Time.deltaTime;
		float L_1 = __this->___timer_13;
		float L_2;
		L_2 = Time_get_deltaTime_m7AB6BFA101D83E1D8F2EF3D5A128AEE9DDBF1A6D(NULL);
		__this->___timer_13 = ((float)il2cpp_codegen_subtract(L_1, L_2));
		// timerText.text = ((int)timer).ToString();
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_3 = __this->___timerText_11;
		float L_4 = __this->___timer_13;
		V_0 = il2cpp_codegen_cast_double_to_int<int32_t>(L_4);
		String_t* L_5;
		L_5 = Int32_ToString_m030E01C24E294D6762FB0B6F37CB541581F55CA5((&V_0), NULL);
		NullCheck(L_3);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_3, L_5);
		// if (timer < 0) LOSE();
		float L_6 = __this->___timer_13;
		if ((!(((float)L_6) < ((float)(0.0f)))))
		{
			goto IL_0047;
		}
	}
	{
		// if (timer < 0) LOSE();
		main_LOSE_m1B99A3FCEF01A21F4E58404FCEC1FA6C46553B56(__this, NULL);
	}

IL_0047:
	{
		// }
		return;
	}
}
// System.Void main::StartBtn()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void main_StartBtn_m029EAE89983662D6F5212686BD890E77F71596E3 (main_t1A11BBC717193895305089E991DE21F2263A0673* __this, const RuntimeMethod* method) 
{
	GameObjectU5BU5D_tFF67550DFCE87096D7A3734EA15B75896B2722CF* V_0 = NULL;
	int32_t V_1 = 0;
	{
		// Time.timeScale = 1;
		Time_set_timeScale_mD6CAA4968D796C4AF198ACFB2267BDBD06DB349C((1.0f), NULL);
		// input.SetActive(false);
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_0 = __this->___input_5;
		NullCheck(L_0);
		GameObject_SetActive_m638E92E1E75E519E5B24CF150B08CA8E0CDFAB92(L_0, (bool)0, NULL);
		// startBtn.SetActive(false);
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_1 = __this->___startBtn_4;
		NullCheck(L_1);
		GameObject_SetActive_m638E92E1E75E519E5B24CF150B08CA8E0CDFAB92(L_1, (bool)0, NULL);
		// foreach (GameObject btn in btns) btn.SetActive(true);
		GameObjectU5BU5D_tFF67550DFCE87096D7A3734EA15B75896B2722CF* L_2 = __this->___btns_8;
		V_0 = L_2;
		V_1 = 0;
		goto IL_003a;
	}

IL_002d:
	{
		// foreach (GameObject btn in btns) btn.SetActive(true);
		GameObjectU5BU5D_tFF67550DFCE87096D7A3734EA15B75896B2722CF* L_3 = V_0;
		int32_t L_4 = V_1;
		NullCheck(L_3);
		int32_t L_5 = L_4;
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_6 = (L_3)->GetAt(static_cast<il2cpp_array_size_t>(L_5));
		// foreach (GameObject btn in btns) btn.SetActive(true);
		NullCheck(L_6);
		GameObject_SetActive_m638E92E1E75E519E5B24CF150B08CA8E0CDFAB92(L_6, (bool)1, NULL);
		int32_t L_7 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add(L_7, 1));
	}

IL_003a:
	{
		// foreach (GameObject btn in btns) btn.SetActive(true);
		int32_t L_8 = V_1;
		GameObjectU5BU5D_tFF67550DFCE87096D7A3734EA15B75896B2722CF* L_9 = V_0;
		NullCheck(L_9);
		if ((((int32_t)L_8) < ((int32_t)((int32_t)(((RuntimeArray*)L_9)->max_length)))))
		{
			goto IL_002d;
		}
	}
	{
		// timer = 30;
		__this->___timer_13 = (30.0f);
		// isPlaying = true;
		__this->___isPlaying_14 = (bool)1;
		// title.fontSize = 100;
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_10 = __this->___title_10;
		NullCheck(L_10);
		Text_set_fontSize_m426338B0A2CDA58609028FFD471EF5F2C9F364D4(L_10, ((int32_t)100), NULL);
		// UpdateQuestion();
		main_UpdateQuestion_mE85E701A382F726FED5FDF3A4D7FD95280030818(__this, NULL);
		// }
		return;
	}
}
// System.Void main::TryAgainBtn()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void main_TryAgainBtn_mE60D627F5299B5CED4D166ABD398CED465950A76 (main_t1A11BBC717193895305089E991DE21F2263A0673* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&SceneManager_tA0EF56A88ACA4A15731AF7FDC10A869FA4C698FA_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// Time.timeScale = 1;
		Time_set_timeScale_mD6CAA4968D796C4AF198ACFB2267BDBD06DB349C((1.0f), NULL);
		// SceneManager.LoadScene(0);
		il2cpp_codegen_runtime_class_init_inline(SceneManager_tA0EF56A88ACA4A15731AF7FDC10A869FA4C698FA_il2cpp_TypeInfo_var);
		SceneManager_LoadScene_mE00D17D79AD74B307F913BBF296A36115548DB6D(0, NULL);
		// }
		return;
	}
}
// System.Void main::ClickBtn(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void main_ClickBtn_mC1929B5027F58744C6F633FC18D7BE49D9BB36CB (main_t1A11BBC717193895305089E991DE21F2263A0673* __this, int32_t ___i0, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// if(questionIndex < 5 && i == char.GetNumericValue(answer[questionIndex]))
		int32_t L_0 = __this->___questionIndex_12;
		if ((((int32_t)L_0) >= ((int32_t)5)))
		{
			goto IL_0038;
		}
	}
	{
		int32_t L_1 = ___i0;
		String_t* L_2 = __this->___answer_17;
		int32_t L_3 = __this->___questionIndex_12;
		NullCheck(L_2);
		Il2CppChar L_4;
		L_4 = String_get_Chars_mC49DF0CD2D3BE7BE97B3AD9C995BE3094F8E36D3(L_2, L_3, NULL);
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		double L_5;
		L_5 = Char_GetNumericValue_mC6F88D2867A2D6EAFB9399277E2A5406CDBB0D96(L_4, NULL);
		if ((!(((double)((double)L_1)) == ((double)L_5))))
		{
			goto IL_0038;
		}
	}
	{
		// questionIndex++;
		int32_t L_6 = __this->___questionIndex_12;
		__this->___questionIndex_12 = ((int32_t)il2cpp_codegen_add(L_6, 1));
		// UpdateQuestion();
		main_UpdateQuestion_mE85E701A382F726FED5FDF3A4D7FD95280030818(__this, NULL);
		return;
	}

IL_0038:
	{
		// else if(i == finalAnswer && questionIndex == 5)
		int32_t L_7 = ___i0;
		int32_t L_8 = __this->___finalAnswer_16;
		if ((!(((uint32_t)L_7) == ((uint32_t)L_8))))
		{
			goto IL_0051;
		}
	}
	{
		int32_t L_9 = __this->___questionIndex_12;
		if ((!(((uint32_t)L_9) == ((uint32_t)5))))
		{
			goto IL_0051;
		}
	}
	{
		// WIN();
		main_WIN_m4B6F896DEC0EC766DAA2E9C8685861AE9F0EC6A7(__this, NULL);
		return;
	}

IL_0051:
	{
		// LOSE();
		main_LOSE_m1B99A3FCEF01A21F4E58404FCEC1FA6C46553B56(__this, NULL);
		// }
		return;
	}
}
// System.Void main::UpdateQuestion()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void main_UpdateQuestion_mE85E701A382F726FED5FDF3A4D7FD95280030818 (main_t1A11BBC717193895305089E991DE21F2263A0673* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral0EBD646B60E1C3FCE0203770591ED3C3D63537DC);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral180D18640B3EF3AEEB0F2B16221B1DD75FC1565D);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral2064F80F811DB79A33C4E51C10221454E30C74AE);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral21ED4C7AF50D987589A9029FC0422151BE3A0FC2);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral262A11B14765132132BB36C155D62CD085035B1E);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral3D714DD3E8E77A697EF557E85ED2B014A96328C5);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral463DF0D1B4A10955AED259E5B64FCE911CFD2144);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral49A7EA21ECB328D154FA2262BB41626D795F4D90);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral4E1AB9B7A40400CB752932191375E56DCD9B66E4);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral68D6B38EFEA69B10C9C23CE03FE8B226C1423DD6);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral7454695E25D304C65D0C1333D8008E862569CAE9);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral75B387A7897CE7621C215035B89C223031380111);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral772B560622741F096D2A869E0F4F4CDFAF4AF569);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral7A84FD2DD90C89AF3B31456B65720D0471E8EC32);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral7BE9A66971DEC7B6BC132AEFD4786EA2AA539505);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral88FD92D554D8DD49EDFAAF0D74D8F6FAC8BE1E80);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral9353229FEAE90F69FD00B32309FF7495D98F2ACE);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral9755BDFEB5F9A49D48C9DE1EB7313122568D3332);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralAE062B38E5AE5EB9EE0CDC807BBBFECEF216B283);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralB16CF3324CA15FF0851B0F99DD86AC638C3E0CAE);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralB9C8705A23DE64A7C23E91CAFA403A15FCF82D21);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralBD7EDB0FB4B6D1A18FC63542875F06A4BA99FBF6);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralCB0B38E085DB4D82F1F8E2D5FFA87679899F8E27);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralE91FE173F59B063D620A934CE1A010F2B114C1F3);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralEA2E8F12196B3367A735F4C71E698E73DDBB43BD);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralEF420ABFDDBDA7B9EE665D85EF62E4A437554003);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralF944DCD635F9801F7AC90A407FBC479964DEC024);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	Il2CppChar V_2 = 0x0;
	{
		// if (questionIndex < 5)
		int32_t L_0 = __this->___questionIndex_12;
		if ((((int32_t)L_0) >= ((int32_t)5)))
		{
			goto IL_01eb;
		}
	}
	{
		// switch (questionIndex)
		int32_t L_1 = __this->___questionIndex_12;
		V_0 = L_1;
		int32_t L_2 = V_0;
		switch (L_2)
		{
			case 0:
			{
				goto IL_002e;
			}
			case 1:
			{
				goto IL_0087;
			}
			case 2:
			{
				goto IL_00e0;
			}
			case 3:
			{
				goto IL_0139;
			}
			case 4:
			{
				goto IL_0192;
			}
		}
	}
	{
		return;
	}

IL_002e:
	{
		// title.text = "how many cards are there in poker?";
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_3 = __this->___title_10;
		NullCheck(L_3);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_3, _stringLiteral4E1AB9B7A40400CB752932191375E56DCD9B66E4);
		// texts[0].text = "8";
		TextU5BU5D_t1D476A037C4542F053D17ADAFA2723F311F9A353* L_4 = __this->___texts_9;
		NullCheck(L_4);
		int32_t L_5 = 0;
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_6 = (L_4)->GetAt(static_cast<il2cpp_array_size_t>(L_5));
		NullCheck(L_6);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_6, _stringLiteralB16CF3324CA15FF0851B0F99DD86AC638C3E0CAE);
		// texts[1].text = "52";
		TextU5BU5D_t1D476A037C4542F053D17ADAFA2723F311F9A353* L_7 = __this->___texts_9;
		NullCheck(L_7);
		int32_t L_8 = 1;
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_9 = (L_7)->GetAt(static_cast<il2cpp_array_size_t>(L_8));
		NullCheck(L_9);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_9, _stringLiteralEA2E8F12196B3367A735F4C71E698E73DDBB43BD);
		// texts[2].text = "343";
		TextU5BU5D_t1D476A037C4542F053D17ADAFA2723F311F9A353* L_10 = __this->___texts_9;
		NullCheck(L_10);
		int32_t L_11 = 2;
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_12 = (L_10)->GetAt(static_cast<il2cpp_array_size_t>(L_11));
		NullCheck(L_12);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_12, _stringLiteral7BE9A66971DEC7B6BC132AEFD4786EA2AA539505);
		// texts[3].text = "0";
		TextU5BU5D_t1D476A037C4542F053D17ADAFA2723F311F9A353* L_13 = __this->___texts_9;
		NullCheck(L_13);
		int32_t L_14 = 3;
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_15 = (L_13)->GetAt(static_cast<il2cpp_array_size_t>(L_14));
		NullCheck(L_15);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_15, _stringLiteralF944DCD635F9801F7AC90A407FBC479964DEC024);
		// break;
		return;
	}

IL_0087:
	{
		// title.text = "what letter comes after J?";
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_16 = __this->___title_10;
		NullCheck(L_16);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_16, _stringLiteral262A11B14765132132BB36C155D62CD085035B1E);
		// texts[0].text = "J";
		TextU5BU5D_t1D476A037C4542F053D17ADAFA2723F311F9A353* L_17 = __this->___texts_9;
		NullCheck(L_17);
		int32_t L_18 = 0;
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_19 = (L_17)->GetAt(static_cast<il2cpp_array_size_t>(L_18));
		NullCheck(L_19);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_19, _stringLiteral0EBD646B60E1C3FCE0203770591ED3C3D63537DC);
		// texts[1].text = "Q";
		TextU5BU5D_t1D476A037C4542F053D17ADAFA2723F311F9A353* L_20 = __this->___texts_9;
		NullCheck(L_20);
		int32_t L_21 = 1;
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_22 = (L_20)->GetAt(static_cast<il2cpp_array_size_t>(L_21));
		NullCheck(L_22);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_22, _stringLiteral49A7EA21ECB328D154FA2262BB41626D795F4D90);
		// texts[2].text = "K";
		TextU5BU5D_t1D476A037C4542F053D17ADAFA2723F311F9A353* L_23 = __this->___texts_9;
		NullCheck(L_23);
		int32_t L_24 = 2;
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_25 = (L_23)->GetAt(static_cast<il2cpp_array_size_t>(L_24));
		NullCheck(L_25);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_25, _stringLiteral3D714DD3E8E77A697EF557E85ED2B014A96328C5);
		// texts[3].text = "A";
		TextU5BU5D_t1D476A037C4542F053D17ADAFA2723F311F9A353* L_26 = __this->___texts_9;
		NullCheck(L_26);
		int32_t L_27 = 3;
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_28 = (L_26)->GetAt(static_cast<il2cpp_array_size_t>(L_27));
		NullCheck(L_28);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_28, _stringLiteralEF420ABFDDBDA7B9EE665D85EF62E4A437554003);
		// break;
		return;
	}

IL_00e0:
	{
		// title.text = "How many suits are there in poker?";
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_29 = __this->___title_10;
		NullCheck(L_29);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_29, _stringLiteral75B387A7897CE7621C215035B89C223031380111);
		// texts[0].text = "4";
		TextU5BU5D_t1D476A037C4542F053D17ADAFA2723F311F9A353* L_30 = __this->___texts_9;
		NullCheck(L_30);
		int32_t L_31 = 0;
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_32 = (L_30)->GetAt(static_cast<il2cpp_array_size_t>(L_31));
		NullCheck(L_32);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_32, _stringLiteral7454695E25D304C65D0C1333D8008E862569CAE9);
		// texts[1].text = "3";
		TextU5BU5D_t1D476A037C4542F053D17ADAFA2723F311F9A353* L_33 = __this->___texts_9;
		NullCheck(L_33);
		int32_t L_34 = 1;
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_35 = (L_33)->GetAt(static_cast<il2cpp_array_size_t>(L_34));
		NullCheck(L_35);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_35, _stringLiteral2064F80F811DB79A33C4E51C10221454E30C74AE);
		// texts[2].text = "2";
		TextU5BU5D_t1D476A037C4542F053D17ADAFA2723F311F9A353* L_36 = __this->___texts_9;
		NullCheck(L_36);
		int32_t L_37 = 2;
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_38 = (L_36)->GetAt(static_cast<il2cpp_array_size_t>(L_37));
		NullCheck(L_38);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_38, _stringLiteral21ED4C7AF50D987589A9029FC0422151BE3A0FC2);
		// texts[3].text = "1";
		TextU5BU5D_t1D476A037C4542F053D17ADAFA2723F311F9A353* L_39 = __this->___texts_9;
		NullCheck(L_39);
		int32_t L_40 = 3;
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_41 = (L_39)->GetAt(static_cast<il2cpp_array_size_t>(L_40));
		NullCheck(L_41);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_41, _stringLiteralE91FE173F59B063D620A934CE1A010F2B114C1F3);
		// break;
		return;
	}

IL_0139:
	{
		// title.text = "what does Q in poker mean?";
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_42 = __this->___title_10;
		NullCheck(L_42);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_42, _stringLiteral772B560622741F096D2A869E0F4F4CDFAF4AF569);
		// texts[0].text = "Ace";
		TextU5BU5D_t1D476A037C4542F053D17ADAFA2723F311F9A353* L_43 = __this->___texts_9;
		NullCheck(L_43);
		int32_t L_44 = 0;
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_45 = (L_43)->GetAt(static_cast<il2cpp_array_size_t>(L_44));
		NullCheck(L_45);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_45, _stringLiteral180D18640B3EF3AEEB0F2B16221B1DD75FC1565D);
		// texts[1].text = "Jack";
		TextU5BU5D_t1D476A037C4542F053D17ADAFA2723F311F9A353* L_46 = __this->___texts_9;
		NullCheck(L_46);
		int32_t L_47 = 1;
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_48 = (L_46)->GetAt(static_cast<il2cpp_array_size_t>(L_47));
		NullCheck(L_48);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_48, _stringLiteral9755BDFEB5F9A49D48C9DE1EB7313122568D3332);
		// texts[2].text = "Queen";
		TextU5BU5D_t1D476A037C4542F053D17ADAFA2723F311F9A353* L_49 = __this->___texts_9;
		NullCheck(L_49);
		int32_t L_50 = 2;
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_51 = (L_49)->GetAt(static_cast<il2cpp_array_size_t>(L_50));
		NullCheck(L_51);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_51, _stringLiteral88FD92D554D8DD49EDFAAF0D74D8F6FAC8BE1E80);
		// texts[3].text = "King";
		TextU5BU5D_t1D476A037C4542F053D17ADAFA2723F311F9A353* L_52 = __this->___texts_9;
		NullCheck(L_52);
		int32_t L_53 = 3;
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_54 = (L_52)->GetAt(static_cast<il2cpp_array_size_t>(L_53));
		NullCheck(L_54);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_54, _stringLiteralAE062B38E5AE5EB9EE0CDC807BBBFECEF216B283);
		// break;
		return;
	}

IL_0192:
	{
		// title.text = "what is my suit?";
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_55 = __this->___title_10;
		NullCheck(L_55);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_55, _stringLiteral7A84FD2DD90C89AF3B31456B65720D0471E8EC32);
		// texts[0].text = "?";
		TextU5BU5D_t1D476A037C4542F053D17ADAFA2723F311F9A353* L_56 = __this->___texts_9;
		NullCheck(L_56);
		int32_t L_57 = 0;
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_58 = (L_56)->GetAt(static_cast<il2cpp_array_size_t>(L_57));
		NullCheck(L_58);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_58, _stringLiteralB9C8705A23DE64A7C23E91CAFA403A15FCF82D21);
		// texts[1].text = "?";
		TextU5BU5D_t1D476A037C4542F053D17ADAFA2723F311F9A353* L_59 = __this->___texts_9;
		NullCheck(L_59);
		int32_t L_60 = 1;
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_61 = (L_59)->GetAt(static_cast<il2cpp_array_size_t>(L_60));
		NullCheck(L_61);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_61, _stringLiteral9353229FEAE90F69FD00B32309FF7495D98F2ACE);
		// texts[2].text = "?";
		TextU5BU5D_t1D476A037C4542F053D17ADAFA2723F311F9A353* L_62 = __this->___texts_9;
		NullCheck(L_62);
		int32_t L_63 = 2;
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_64 = (L_62)->GetAt(static_cast<il2cpp_array_size_t>(L_63));
		NullCheck(L_64);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_64, _stringLiteralCB0B38E085DB4D82F1F8E2D5FFA87679899F8E27);
		// texts[3].text = "?";
		TextU5BU5D_t1D476A037C4542F053D17ADAFA2723F311F9A353* L_65 = __this->___texts_9;
		NullCheck(L_65);
		int32_t L_66 = 3;
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_67 = (L_65)->GetAt(static_cast<il2cpp_array_size_t>(L_66));
		NullCheck(L_67);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_67, _stringLiteral463DF0D1B4A10955AED259E5B64FCE911CFD2144);
		// break;
		return;
	}

IL_01eb:
	{
		// title.text = "what is your suit?";
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_68 = __this->___title_10;
		NullCheck(L_68);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_68, _stringLiteral68D6B38EFEA69B10C9C23CE03FE8B226C1423DD6);
		// if (playerName.Length >= 4 && char.IsNumber(playerName[2]))
		String_t* L_69 = __this->___playerName_15;
		NullCheck(L_69);
		int32_t L_70;
		L_70 = String_get_Length_m42625D67623FA5CC7A44D47425CE86FB946542D2_inline(L_69, NULL);
		if ((((int32_t)L_70) < ((int32_t)4)))
		{
			goto IL_02e9;
		}
	}
	{
		String_t* L_71 = __this->___playerName_15;
		NullCheck(L_71);
		Il2CppChar L_72;
		L_72 = String_get_Chars_mC49DF0CD2D3BE7BE97B3AD9C995BE3094F8E36D3(L_71, 2, NULL);
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_73;
		L_73 = Char_IsNumber_mDC791095BD939D5BC25410006FB6619CB77C2716(L_72, NULL);
		if (!L_73)
		{
			goto IL_02e9;
		}
	}
	{
		// int num = (int)char.GetNumericValue(playerName[2]);
		String_t* L_74 = __this->___playerName_15;
		NullCheck(L_74);
		Il2CppChar L_75;
		L_75 = String_get_Chars_mC49DF0CD2D3BE7BE97B3AD9C995BE3094F8E36D3(L_74, 2, NULL);
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		double L_76;
		L_76 = Char_GetNumericValue_mC6F88D2867A2D6EAFB9399277E2A5406CDBB0D96(L_75, NULL);
		V_1 = il2cpp_codegen_cast_double_to_int<int32_t>(L_76);
		// if((int)timer >= 10 &&secret(num, (int)timer) == 20 && playerName[3].ToString()+playerName[4].ToString()+playerName[5].ToString()+playerName[6].ToString()+playerName[7].ToString() == "shiya")
		float L_77 = __this->___timer_13;
		if ((((int32_t)il2cpp_codegen_cast_double_to_int<int32_t>(L_77)) < ((int32_t)((int32_t)10))))
		{
			goto IL_02e9;
		}
	}
	{
		int32_t L_78 = V_1;
		float L_79 = __this->___timer_13;
		int32_t L_80;
		L_80 = main_secret_m4A232F0CFBFF68EA2BC226040CD9976DF0059172(__this, L_78, il2cpp_codegen_cast_double_to_int<int32_t>(L_79), NULL);
		if ((!(((uint32_t)L_80) == ((uint32_t)((int32_t)20)))))
		{
			goto IL_02e9;
		}
	}
	{
		StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248* L_81 = (StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248*)(StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248*)SZArrayNew(StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248_il2cpp_TypeInfo_var, (uint32_t)5);
		StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248* L_82 = L_81;
		String_t* L_83 = __this->___playerName_15;
		NullCheck(L_83);
		Il2CppChar L_84;
		L_84 = String_get_Chars_mC49DF0CD2D3BE7BE97B3AD9C995BE3094F8E36D3(L_83, 3, NULL);
		V_2 = L_84;
		String_t* L_85;
		L_85 = Char_ToString_m2A308731F9577C06AF3C0901234E2EAC8327410C((&V_2), NULL);
		NullCheck(L_82);
		ArrayElementTypeCheck (L_82, L_85);
		(L_82)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)L_85);
		StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248* L_86 = L_82;
		String_t* L_87 = __this->___playerName_15;
		NullCheck(L_87);
		Il2CppChar L_88;
		L_88 = String_get_Chars_mC49DF0CD2D3BE7BE97B3AD9C995BE3094F8E36D3(L_87, 4, NULL);
		V_2 = L_88;
		String_t* L_89;
		L_89 = Char_ToString_m2A308731F9577C06AF3C0901234E2EAC8327410C((&V_2), NULL);
		NullCheck(L_86);
		ArrayElementTypeCheck (L_86, L_89);
		(L_86)->SetAt(static_cast<il2cpp_array_size_t>(1), (String_t*)L_89);
		StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248* L_90 = L_86;
		String_t* L_91 = __this->___playerName_15;
		NullCheck(L_91);
		Il2CppChar L_92;
		L_92 = String_get_Chars_mC49DF0CD2D3BE7BE97B3AD9C995BE3094F8E36D3(L_91, 5, NULL);
		V_2 = L_92;
		String_t* L_93;
		L_93 = Char_ToString_m2A308731F9577C06AF3C0901234E2EAC8327410C((&V_2), NULL);
		NullCheck(L_90);
		ArrayElementTypeCheck (L_90, L_93);
		(L_90)->SetAt(static_cast<il2cpp_array_size_t>(2), (String_t*)L_93);
		StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248* L_94 = L_90;
		String_t* L_95 = __this->___playerName_15;
		NullCheck(L_95);
		Il2CppChar L_96;
		L_96 = String_get_Chars_mC49DF0CD2D3BE7BE97B3AD9C995BE3094F8E36D3(L_95, 6, NULL);
		V_2 = L_96;
		String_t* L_97;
		L_97 = Char_ToString_m2A308731F9577C06AF3C0901234E2EAC8327410C((&V_2), NULL);
		NullCheck(L_94);
		ArrayElementTypeCheck (L_94, L_97);
		(L_94)->SetAt(static_cast<il2cpp_array_size_t>(3), (String_t*)L_97);
		StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248* L_98 = L_94;
		String_t* L_99 = __this->___playerName_15;
		NullCheck(L_99);
		Il2CppChar L_100;
		L_100 = String_get_Chars_mC49DF0CD2D3BE7BE97B3AD9C995BE3094F8E36D3(L_99, 7, NULL);
		V_2 = L_100;
		String_t* L_101;
		L_101 = Char_ToString_m2A308731F9577C06AF3C0901234E2EAC8327410C((&V_2), NULL);
		NullCheck(L_98);
		ArrayElementTypeCheck (L_98, L_101);
		(L_98)->SetAt(static_cast<il2cpp_array_size_t>(4), (String_t*)L_101);
		String_t* L_102;
		L_102 = String_Concat_m6B0734B65813C8EA093D78E5C2D16534EB6FE8C0(L_98, NULL);
		bool L_103;
		L_103 = String_op_Equality_m0D685A924E5CD78078F248ED1726DA5A9D7D6AC0(L_102, _stringLiteralBD7EDB0FB4B6D1A18FC63542875F06A4BA99FBF6, NULL);
		if (!L_103)
		{
			goto IL_02e9;
		}
	}
	{
		// finalAnswer = 1;
		__this->___finalAnswer_16 = 1;
	}

IL_02e9:
	{
		// }
		return;
	}
}
// System.Int32 main::secret(System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t main_secret_m4A232F0CFBFF68EA2BC226040CD9976DF0059172 (main_t1A11BBC717193895305089E991DE21F2263A0673* __this, int32_t ___x0, int32_t ___y1, const RuntimeMethod* method) 
{
	{
		// if (y == 8 && x == 5){
		int32_t L_0 = ___y1;
		if ((!(((uint32_t)L_0) == ((uint32_t)8))))
		{
			goto IL_0021;
		}
	}
	{
		int32_t L_1 = ___x0;
		if ((!(((uint32_t)L_1) == ((uint32_t)5))))
		{
			goto IL_0021;
		}
	}
	{
		// return y + x + 2 + questionIndex + name.Length;
		int32_t L_2 = ___y1;
		int32_t L_3 = ___x0;
		int32_t L_4 = __this->___questionIndex_12;
		String_t* L_5;
		L_5 = Object_get_name_mAC2F6B897CF1303BA4249B4CB55271AFACBB6392(__this, NULL);
		NullCheck(L_5);
		int32_t L_6;
		L_6 = String_get_Length_m42625D67623FA5CC7A44D47425CE86FB946542D2_inline(L_5, NULL);
		return ((int32_t)il2cpp_codegen_add(((int32_t)il2cpp_codegen_add(((int32_t)il2cpp_codegen_add(((int32_t)il2cpp_codegen_add(L_2, L_3)), 2)), L_4)), L_6));
	}

IL_0021:
	{
		// else if(y == 11 || x == 0){
		int32_t L_7 = ___y1;
		if ((((int32_t)L_7) == ((int32_t)((int32_t)11))))
		{
			goto IL_0029;
		}
	}
	{
		int32_t L_8 = ___x0;
		if (L_8)
		{
			goto IL_0033;
		}
	}

IL_0029:
	{
		// return questionIndex + 17;
		int32_t L_9 = __this->___questionIndex_12;
		return ((int32_t)il2cpp_codegen_add(L_9, ((int32_t)17)));
	}

IL_0033:
	{
		// else if(y == 0 && x == 11)
		int32_t L_10 = ___y1;
		if (L_10)
		{
			goto IL_0050;
		}
	}
	{
		int32_t L_11 = ___x0;
		if ((!(((uint32_t)L_11) == ((uint32_t)((int32_t)11)))))
		{
			goto IL_0050;
		}
	}
	{
		// return playerName.Length * questionIndex / 2;
		String_t* L_12 = __this->___playerName_15;
		NullCheck(L_12);
		int32_t L_13;
		L_13 = String_get_Length_m42625D67623FA5CC7A44D47425CE86FB946542D2_inline(L_12, NULL);
		int32_t L_14 = __this->___questionIndex_12;
		return ((int32_t)(((int32_t)il2cpp_codegen_multiply(L_13, L_14))/2));
	}

IL_0050:
	{
		// else if(y <= 0 || x > 10)
		int32_t L_15 = ___y1;
		if ((((int32_t)L_15) <= ((int32_t)0)))
		{
			goto IL_0059;
		}
	}
	{
		int32_t L_16 = ___x0;
		if ((((int32_t)L_16) <= ((int32_t)((int32_t)10))))
		{
			goto IL_0064;
		}
	}

IL_0059:
	{
		// return (int)timer * 21;
		float L_17 = __this->___timer_13;
		return ((int32_t)il2cpp_codegen_multiply(il2cpp_codegen_cast_double_to_int<int32_t>(L_17), ((int32_t)21)));
	}

IL_0064:
	{
		// return secret(x + 1, y - 1);
		int32_t L_18 = ___x0;
		int32_t L_19 = ___y1;
		int32_t L_20;
		L_20 = main_secret_m4A232F0CFBFF68EA2BC226040CD9976DF0059172(__this, ((int32_t)il2cpp_codegen_add(L_18, 1)), ((int32_t)il2cpp_codegen_subtract(L_19, 1)), NULL);
		return L_20;
	}
}
// System.Void main::WIN()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void main_WIN_m4B6F896DEC0EC766DAA2E9C8685861AE9F0EC6A7 (main_t1A11BBC717193895305089E991DE21F2263A0673* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral8DAE88EAE46501EE3F1AF9B2923FE04DE343E4B3);
		s_Il2CppMethodInitialized = true;
	}
	{
		// Time.timeScale = 0;
		Time_set_timeScale_mD6CAA4968D796C4AF198ACFB2267BDBD06DB349C((0.0f), NULL);
		// joker.SetActive(true);
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_0 = __this->___joker_7;
		NullCheck(L_0);
		GameObject_SetActive_m638E92E1E75E519E5B24CF150B08CA8E0CDFAB92(L_0, (bool)1, NULL);
		// title.text = "LoTuX{Y0u_4re                    }";
		Text_tD60B2346DAA6666BF0D822FF607F0B220C2B9E62* L_1 = __this->___title_10;
		NullCheck(L_1);
		VirtualActionInvoker1< String_t* >::Invoke(75 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_1, _stringLiteral8DAE88EAE46501EE3F1AF9B2923FE04DE343E4B3);
		// }
		return;
	}
}
// System.Void main::LOSE()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void main_LOSE_m1B99A3FCEF01A21F4E58404FCEC1FA6C46553B56 (main_t1A11BBC717193895305089E991DE21F2263A0673* __this, const RuntimeMethod* method) 
{
	{
		// Time.timeScale = 0;
		Time_set_timeScale_mD6CAA4968D796C4AF198ACFB2267BDBD06DB349C((0.0f), NULL);
		// lose.SetActive(true);
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_0 = __this->___lose_6;
		NullCheck(L_0);
		GameObject_SetActive_m638E92E1E75E519E5B24CF150B08CA8E0CDFAB92(L_0, (bool)1, NULL);
		// }
		return;
	}
}
// System.Void main::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void main__ctor_m130E0270AE02CDA3754528B71F901B97C4AE91BA (main_t1A11BBC717193895305089E991DE21F2263A0673* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral3F5BA7FB1F7E7D244143237CC72674F496DF7066);
		s_Il2CppMethodInitialized = true;
	}
	{
		// int finalAnswer = 99;
		__this->___finalAnswer_16 = ((int32_t)99);
		// string answer = "12022";
		__this->___answer_17 = _stringLiteral3F5BA7FB1F7E7D244143237CC72674F496DF7066;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___answer_17), (void*)_stringLiteral3F5BA7FB1F7E7D244143237CC72674F496DF7066);
		MonoBehaviour__ctor_m592DB0105CA0BC97AA1C5F4AD27B12D68A3B7C1E(__this, NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t String_get_Length_m42625D67623FA5CC7A44D47425CE86FB946542D2_inline (String_t* __this, const RuntimeMethod* method) 
{
	{
		int32_t L_0 = __this->____stringLength_4;
		return L_0;
	}
}
