﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void UnityEngine.VFX.VFXEventAttribute::.ctor(System.IntPtr,System.Boolean,UnityEngine.VFX.VisualEffectAsset)
extern void VFXEventAttribute__ctor_m08E26E4F79DA1062FC43501FDFE00B9EF3ED3AE1 (void);
// 0x00000002 System.IntPtr UnityEngine.VFX.VFXEventAttribute::Internal_Create()
extern void VFXEventAttribute_Internal_Create_m4714640E9629958FFD68B42101FC0B607BCBA72A (void);
// 0x00000003 UnityEngine.VFX.VFXEventAttribute UnityEngine.VFX.VFXEventAttribute::Internal_InstanciateVFXEventAttribute(UnityEngine.VFX.VisualEffectAsset)
extern void VFXEventAttribute_Internal_InstanciateVFXEventAttribute_m731621C31A8F517EB3DE20EA75A5358CB0320473 (void);
// 0x00000004 System.Void UnityEngine.VFX.VFXEventAttribute::Internal_InitFromAsset(UnityEngine.VFX.VisualEffectAsset)
extern void VFXEventAttribute_Internal_InitFromAsset_mFA13F75CCECE6D2DAD270E37126F211724D5EFD2 (void);
// 0x00000005 System.Void UnityEngine.VFX.VFXEventAttribute::Release()
extern void VFXEventAttribute_Release_m959FB9B7EEC401D763A16AC1188F18B7F5B2D8F2 (void);
// 0x00000006 System.Void UnityEngine.VFX.VFXEventAttribute::Finalize()
extern void VFXEventAttribute_Finalize_m7922B5B3EF84DB5BE447C5A6F4F6B5F00B3E4AA4 (void);
// 0x00000007 System.Void UnityEngine.VFX.VFXEventAttribute::Dispose()
extern void VFXEventAttribute_Dispose_m172293D888316328F19F4C7E03D50CD178E0EB36 (void);
// 0x00000008 System.Void UnityEngine.VFX.VFXEventAttribute::Internal_Destroy(System.IntPtr)
extern void VFXEventAttribute_Internal_Destroy_m97A525FB5B879BC8BAC01DEDB1E765817F0B2179 (void);
// 0x00000009 System.Void UnityEngine.VFX.VFXExpressionValues::.ctor()
extern void VFXExpressionValues__ctor_mB5923888F1BBEEE55955E24514A69629D932DDD0 (void);
// 0x0000000A UnityEngine.VFX.VFXExpressionValues UnityEngine.VFX.VFXExpressionValues::CreateExpressionValuesWrapper(System.IntPtr)
extern void VFXExpressionValues_CreateExpressionValuesWrapper_mE5ADD307480A8F6350443C5FC68CD649CCD798C4 (void);
// 0x0000000B System.Void UnityEngine.VFX.VFXManager::.cctor()
extern void VFXManager__cctor_m63A583F517980CD185F5E8B7EBB1A8F62536E360 (void);
// 0x0000000C System.Void UnityEngine.VFX.VFXSpawnerCallbacks::OnPlay(UnityEngine.VFX.VFXSpawnerState,UnityEngine.VFX.VFXExpressionValues,UnityEngine.VFX.VisualEffect)
// 0x0000000D System.Void UnityEngine.VFX.VFXSpawnerCallbacks::OnUpdate(UnityEngine.VFX.VFXSpawnerState,UnityEngine.VFX.VFXExpressionValues,UnityEngine.VFX.VisualEffect)
// 0x0000000E System.Void UnityEngine.VFX.VFXSpawnerCallbacks::OnStop(UnityEngine.VFX.VFXSpawnerState,UnityEngine.VFX.VFXExpressionValues,UnityEngine.VFX.VisualEffect)
// 0x0000000F System.Void UnityEngine.VFX.VFXSpawnerCallbacks::.ctor()
extern void VFXSpawnerCallbacks__ctor_mF8C2AB380D2D25B5309E22DA5A0F48ECE40BAAEB (void);
// 0x00000010 System.Void UnityEngine.VFX.VFXSpawnerState::.ctor(System.IntPtr,System.Boolean)
extern void VFXSpawnerState__ctor_mDF51A64C76B610ED8B1BF46C3CB6F8224B246392 (void);
// 0x00000011 UnityEngine.VFX.VFXSpawnerState UnityEngine.VFX.VFXSpawnerState::CreateSpawnerStateWrapper()
extern void VFXSpawnerState_CreateSpawnerStateWrapper_mDA8B35B76FD78C845BE52B895C930437E2FC03F7 (void);
// 0x00000012 System.Void UnityEngine.VFX.VFXSpawnerState::SetWrapValue(System.IntPtr)
extern void VFXSpawnerState_SetWrapValue_m07CE08E6A5546B21559C8D73669EA0308A2470D6 (void);
// 0x00000013 System.Void UnityEngine.VFX.VFXSpawnerState::Release()
extern void VFXSpawnerState_Release_m59F57A6E6C6C8FCA65E61C9D856847493997DBF8 (void);
// 0x00000014 System.Void UnityEngine.VFX.VFXSpawnerState::Finalize()
extern void VFXSpawnerState_Finalize_mAE69A225C7EC591B6B1DE3B01560F5639C6A7839 (void);
// 0x00000015 System.Void UnityEngine.VFX.VFXSpawnerState::Dispose()
extern void VFXSpawnerState_Dispose_m7098E99835290AAF0DFFE32EE2D901CA455975A4 (void);
// 0x00000016 System.Void UnityEngine.VFX.VFXSpawnerState::Internal_Destroy(System.IntPtr)
extern void VFXSpawnerState_Internal_Destroy_m84F996A6513A6D97973152AC3AFFAF83BAC2BF4F (void);
// 0x00000017 System.Void UnityEngine.VFX.VisualEffectObject::.ctor()
extern void VisualEffectObject__ctor_m2D49AA821FEFA36E48409C03455DE173BCEB3837 (void);
// 0x00000018 System.Void UnityEngine.VFX.VisualEffectAsset::.ctor()
extern void VisualEffectAsset__ctor_m84C59D5BB45858C0EA43C5C2E9A9DAA644CA3680 (void);
// 0x00000019 System.Void UnityEngine.VFX.VisualEffectAsset::.cctor()
extern void VisualEffectAsset__cctor_mDB710F5C5B6EB21B30AD257D084FA1C575F2E557 (void);
// 0x0000001A System.Void UnityEngine.VFX.VFXOutputEventArgs::.ctor(System.Int32,UnityEngine.VFX.VFXEventAttribute)
extern void VFXOutputEventArgs__ctor_m4A6030F4BF7E27F5F682E0FC4211F53DF866ED56 (void);
// 0x0000001B UnityEngine.VFX.VisualEffectAsset UnityEngine.VFX.VisualEffect::get_visualEffectAsset()
extern void VisualEffect_get_visualEffectAsset_m301FCE98B138CAB2E16B46CE365538ECA8AF5F00 (void);
// 0x0000001C UnityEngine.VFX.VFXEventAttribute UnityEngine.VFX.VisualEffect::CreateVFXEventAttribute()
extern void VisualEffect_CreateVFXEventAttribute_mC4611FC064DF24028BA3E60D3D450B95541BEB6E (void);
// 0x0000001D UnityEngine.VFX.VFXEventAttribute UnityEngine.VFX.VisualEffect::InvokeGetCachedEventAttributeForOutputEvent_Internal(UnityEngine.VFX.VisualEffect)
extern void VisualEffect_InvokeGetCachedEventAttributeForOutputEvent_Internal_mCE4900AB532DE4A22B54740FD8C9A0225567955F (void);
// 0x0000001E System.Void UnityEngine.VFX.VisualEffect::InvokeOutputEventReceived_Internal(UnityEngine.VFX.VisualEffect,System.Int32)
extern void VisualEffect_InvokeOutputEventReceived_Internal_m3B285A8384D57305435FE17E787B2DF95CC74681 (void);
static Il2CppMethodPointer s_methodPointers[30] = 
{
	VFXEventAttribute__ctor_m08E26E4F79DA1062FC43501FDFE00B9EF3ED3AE1,
	VFXEventAttribute_Internal_Create_m4714640E9629958FFD68B42101FC0B607BCBA72A,
	VFXEventAttribute_Internal_InstanciateVFXEventAttribute_m731621C31A8F517EB3DE20EA75A5358CB0320473,
	VFXEventAttribute_Internal_InitFromAsset_mFA13F75CCECE6D2DAD270E37126F211724D5EFD2,
	VFXEventAttribute_Release_m959FB9B7EEC401D763A16AC1188F18B7F5B2D8F2,
	VFXEventAttribute_Finalize_m7922B5B3EF84DB5BE447C5A6F4F6B5F00B3E4AA4,
	VFXEventAttribute_Dispose_m172293D888316328F19F4C7E03D50CD178E0EB36,
	VFXEventAttribute_Internal_Destroy_m97A525FB5B879BC8BAC01DEDB1E765817F0B2179,
	VFXExpressionValues__ctor_mB5923888F1BBEEE55955E24514A69629D932DDD0,
	VFXExpressionValues_CreateExpressionValuesWrapper_mE5ADD307480A8F6350443C5FC68CD649CCD798C4,
	VFXManager__cctor_m63A583F517980CD185F5E8B7EBB1A8F62536E360,
	NULL,
	NULL,
	NULL,
	VFXSpawnerCallbacks__ctor_mF8C2AB380D2D25B5309E22DA5A0F48ECE40BAAEB,
	VFXSpawnerState__ctor_mDF51A64C76B610ED8B1BF46C3CB6F8224B246392,
	VFXSpawnerState_CreateSpawnerStateWrapper_mDA8B35B76FD78C845BE52B895C930437E2FC03F7,
	VFXSpawnerState_SetWrapValue_m07CE08E6A5546B21559C8D73669EA0308A2470D6,
	VFXSpawnerState_Release_m59F57A6E6C6C8FCA65E61C9D856847493997DBF8,
	VFXSpawnerState_Finalize_mAE69A225C7EC591B6B1DE3B01560F5639C6A7839,
	VFXSpawnerState_Dispose_m7098E99835290AAF0DFFE32EE2D901CA455975A4,
	VFXSpawnerState_Internal_Destroy_m84F996A6513A6D97973152AC3AFFAF83BAC2BF4F,
	VisualEffectObject__ctor_m2D49AA821FEFA36E48409C03455DE173BCEB3837,
	VisualEffectAsset__ctor_m84C59D5BB45858C0EA43C5C2E9A9DAA644CA3680,
	VisualEffectAsset__cctor_mDB710F5C5B6EB21B30AD257D084FA1C575F2E557,
	VFXOutputEventArgs__ctor_m4A6030F4BF7E27F5F682E0FC4211F53DF866ED56,
	VisualEffect_get_visualEffectAsset_m301FCE98B138CAB2E16B46CE365538ECA8AF5F00,
	VisualEffect_CreateVFXEventAttribute_mC4611FC064DF24028BA3E60D3D450B95541BEB6E,
	VisualEffect_InvokeGetCachedEventAttributeForOutputEvent_Internal_mCE4900AB532DE4A22B54740FD8C9A0225567955F,
	VisualEffect_InvokeOutputEventReceived_Internal_m3B285A8384D57305435FE17E787B2DF95CC74681,
};
extern void VFXOutputEventArgs__ctor_m4A6030F4BF7E27F5F682E0FC4211F53DF866ED56_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[1] = 
{
	{ 0x0600001A, VFXOutputEventArgs__ctor_m4A6030F4BF7E27F5F682E0FC4211F53DF866ED56_AdjustorThunk },
};
static const int32_t s_InvokerIndices[30] = 
{
	792,
	5076,
	4864,
	2680,
	3311,
	3311,
	3311,
	5001,
	3311,
	4863,
	5107,
	0,
	0,
	0,
	3311,
	1487,
	5081,
	2664,
	3311,
	3311,
	3311,
	5001,
	3311,
	3311,
	5107,
	1386,
	3226,
	3226,
	4864,
	4632,
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_UnityEngine_VFXModule_CodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_VFXModule_CodeGenModule = 
{
	"UnityEngine.VFXModule.dll",
	30,
	s_methodPointers,
	1,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
