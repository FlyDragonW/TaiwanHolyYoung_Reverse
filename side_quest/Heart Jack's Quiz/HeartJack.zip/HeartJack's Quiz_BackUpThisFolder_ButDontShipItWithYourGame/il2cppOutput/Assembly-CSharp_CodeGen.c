﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void main::ReadName(System.String)
extern void main_ReadName_mEC30A290A6F87931FA5869E3BF6E6F0FFE539DE8 (void);
// 0x00000002 System.Void main::Update()
extern void main_Update_m8A9D6818CB69459A554B68231329A0100C1D2830 (void);
// 0x00000003 System.Void main::StartBtn()
extern void main_StartBtn_m029EAE89983662D6F5212686BD890E77F71596E3 (void);
// 0x00000004 System.Void main::TryAgainBtn()
extern void main_TryAgainBtn_mE60D627F5299B5CED4D166ABD398CED465950A76 (void);
// 0x00000005 System.Void main::ClickBtn(System.Int32)
extern void main_ClickBtn_mC1929B5027F58744C6F633FC18D7BE49D9BB36CB (void);
// 0x00000006 System.Void main::UpdateQuestion()
extern void main_UpdateQuestion_mE85E701A382F726FED5FDF3A4D7FD95280030818 (void);
// 0x00000007 System.Int32 main::secret(System.Int32,System.Int32)
extern void main_secret_m4A232F0CFBFF68EA2BC226040CD9976DF0059172 (void);
// 0x00000008 System.Void main::WIN()
extern void main_WIN_m4B6F896DEC0EC766DAA2E9C8685861AE9F0EC6A7 (void);
// 0x00000009 System.Void main::LOSE()
extern void main_LOSE_m1B99A3FCEF01A21F4E58404FCEC1FA6C46553B56 (void);
// 0x0000000A System.Void main::.ctor()
extern void main__ctor_m130E0270AE02CDA3754528B71F901B97C4AE91BA (void);
static Il2CppMethodPointer s_methodPointers[10] = 
{
	main_ReadName_mEC30A290A6F87931FA5869E3BF6E6F0FFE539DE8,
	main_Update_m8A9D6818CB69459A554B68231329A0100C1D2830,
	main_StartBtn_m029EAE89983662D6F5212686BD890E77F71596E3,
	main_TryAgainBtn_mE60D627F5299B5CED4D166ABD398CED465950A76,
	main_ClickBtn_mC1929B5027F58744C6F633FC18D7BE49D9BB36CB,
	main_UpdateQuestion_mE85E701A382F726FED5FDF3A4D7FD95280030818,
	main_secret_m4A232F0CFBFF68EA2BC226040CD9976DF0059172,
	main_WIN_m4B6F896DEC0EC766DAA2E9C8685861AE9F0EC6A7,
	main_LOSE_m1B99A3FCEF01A21F4E58404FCEC1FA6C46553B56,
	main__ctor_m130E0270AE02CDA3754528B71F901B97C4AE91BA,
};
static const int32_t s_InvokerIndices[10] = 
{
	2680,
	3311,
	3311,
	3311,
	2662,
	3311,
	1052,
	3311,
	3311,
	3311,
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule = 
{
	"Assembly-CSharp.dll",
	10,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
